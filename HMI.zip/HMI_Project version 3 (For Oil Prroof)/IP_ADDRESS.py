import socket
import os

hostname = socket.gethostname()
IPAddr = socket.gethostbyname(hostname)

print("Your Computer Name is:" + hostname)
print("Your Computer IP Address is:" + IPAddr)
print(os.getlogin())

## https://stackoverflow.com/questions/62440755/how-do-i-get-my-local-ip-address-from-a-python-script-on-linux
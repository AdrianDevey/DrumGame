import matplotlib.pyplot as plt
import numpy as np

import Data

#plt.style.use('_mpl-gallery')

# make data
x = Data.timestamps
y = Data.temperature

fig, ax = plt.subplots()
plt.subplots_adjust(bottom=.2)
#ax.plot(timestamps, temperatures, marker='o', linestyle='-', color='gray')
ax.plot( Data.timestamps, Data.temperature, 'o-', color='Red')
ax.set_title('Temperature Thermocouple')
ax.set_xlabel('Timestamp')
ax.set_ylabel('Temperature (°C)')
ax.grid(True)
#ax.xaxis.set_major_locator(plt.MaxNLocator(10))
plt.xticks(rotation=45)


plt.show() 
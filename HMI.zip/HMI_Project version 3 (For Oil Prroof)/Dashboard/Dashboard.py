from tkinter import *
from turtle import width
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

import Data

# Chart 1: Temperature - Thermocouple
def plot_temperature_chart():

    fig, ax = plt.subplots()
    plt.subplots_adjust(bottom=.2)
    #ax.plot(timestamps, temperatures, marker='o', linestyle='-', color='gray')
    ax.plot( Data.temperature, linestyle='-', color='Red')
    ax.set_title('Temperature Thermocouple')
    ax.set_xlabel('Timestamp')
    ax.set_ylabel('Temperature (°C)')
    ax.grid(True)
    #ax.xaxis.set_major_locator(plt.MaxNLocator(10))
    plt.xticks(rotation=0)
    
    # Embedding the plot into tkinter window
    canvas = FigureCanvasTkAgg(fig, chart_frame)
    canvas.draw()
    canvas.get_tk_widget().place(width = 512, height=250)

    fig1, ax1 = plt.subplots()
    plt.subplots_adjust(bottom=.2)
    #ax.plot(timestamps, temperatures, marker='o', linestyle='-', color='gray')
    ax1.plot( Data.temperature, linestyle='-', color='Blue')
    ax1.set_title('Sample Monitoring')
    ax1.set_xlabel('Timestamp')
    ax1.set_ylabel('Temperature (°C)')
    ax1.grid(True)
    #)
    #plt.xticks(rotation=45)
    plt.xticks(rotation=0)
    
    
    # Embedding the plot into tkinter window
    canvas1 = FigureCanvasTkAgg(fig1, chart_frame)
    canvas1.draw()
    canvas1.get_tk_widget().place(width = 512, height=250, x= 512, y = 0)


# Chart 1: Temperature - Thermocouple
def plot_sample_chart():

    return



# Create the main tkinter window
root = Tk()
root.title('Data Monitoring')
root.geometry("1024x600")
# Create a frame for the chart
chart_frame = Frame(root)
chart_frame.pack(fill="both", expand=True)




# Initial plot when the application starts
plot_temperature_chart()
plot_sample_chart()

# Start the tkinter main loop
root.mainloop()
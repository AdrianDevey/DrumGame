import pyodbc

class Module:
    db = "DRIVER={SQL Server};SERVER=172.29.3.139;DATABASE=db_RaspberryPiHMI;UID=sa;PWD=sa1234a*;"
    conn = pyodbc.connect(db)
    cursor = conn.cursor()

    def __init__(self):
        self.boolPath = False
        self.query = ""
        self.parameter = None
        self.caption = ""

    @staticmethod
    def openquery():
        try:
            Module.conn = pyodbc.connect(Module.db)
        except Exception as e:
            print(f"Error connecting to database: {e}")

    @staticmethod
    def opencommand():
        try:
            Module.cursor = Module.conn.cursor()
            if Module.parameter != None:
                Module.cursor.execute(Module.query, Module.parameter)
            else:
                Module.cursor.execute(Module.query)
        except Exception as e:
            print(f"Error executing command: {e}")

    @staticmethod
    def exenonQuery():
        try:
            cnt = Module.cursor.rowcount
            return cnt
        except Exception as e:
            print(f"Error executing non query: {e}")
            return 0

    @staticmethod
    def exeReader():
        try:
            reader = Module.cursor.fetchall()
            return reader
        except Exception as e:
            print(f"Error executing reader: {e}")

    @staticmethod
    def closeqry():
        try:
            Module.conn.close()
        except Exception as e:
            print(f"Error closing connection: {e}")



##### SAMPLE USAGE: ####################################################

# module_instance = Module()
# Module.query = "SELECT * FROM RPI_Operation WHERE fldId = ?"
# Module.parameter = '1'

# Module.openquery()
# Module.opencommand()
# rows = Module.exeReader()
# if rows:
#     for row in rows:
#         print(row)
# Module.closeqry()



import module_v2 as db

# Temperature - Thermocouple Data

db.Module.openquery()
db.Module.query = "SELECT * FROM RPI_Thermocouple ORDER BY fldId OFFSET(SELECT COUNT (fldTemperature) - ? FROM RPI_Thermocouple ) ROWS"
db.Module.parameter = 100
db.Module.opencommand()
data = db.Module.exeReader()

timestamps = [row.fldStartTime.strftime("%I:%M:%S %p")  for row in data]
temperature = [row.fldTemperature for row in data]
print(timestamps)
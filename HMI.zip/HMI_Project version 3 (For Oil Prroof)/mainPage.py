from tkinter import *
from tkinter.font import BOLD

# Import other python files
import Pages.OperationPage as OperationPage
import Pages.RunPage as RunPage
import Pages.DowntimePage as DowntimePage
import Pages.MonitorPage as MonitorPage
import Pages.HistoryPage as  HistoryPage
import Pages.MaintenancePage as MaintenancePage
import Pages.socPage as SOCPage
import Pages.DischargeWeightMonitoringPage as DischargePage

# Current Machine Information
import Tools.MachineInfo as Machine


class MainApp(Frame):
    def __init__(self, master):
        super().__init__(master)
        self.current_active_indicator = None

        # self.open_button = Button(self, text="Open Second tkinter File", command=self.open_second_app)
        # self.open_button.pack(pady=20)

        # -- Title --
        global main_lbl_machineId, main_lbl_machineName
        lbl_title =  Label(
            sideFrame,
            text = "PE-IOT-HMI",
            font = ("Bahnschrift", 25, BOLD),
            justify = LEFT,
            fg="white",
            bg = "#1253a3",
            anchor = "w")
        lbl_title.pack(side = TOP, fill = BOTH, pady=(0,10))

        main_lbl_machineId =  Label(
            sideFrame,
            text = Machine.machineId,
            font = ("Bahnschrift", 20, "bold"),
            justify = LEFT,
            fg="white",
            bg = "#1253a3",
            anchor = W)
        main_lbl_machineId.pack(side = TOP, fill = BOTH, padx = (25,0))
        
        main_lbl_machineName =  Label(
            sideFrame,
            text = Machine.machineName,
            font = ("Bahnschrift", 12),
            justify = LEFT,
            fg="white",
            bg = "#1253a3",
            anchor = W,
            wraplength=200)
        main_lbl_machineName.pack(side = TOP, fill = BOTH, padx = (25,0))

        # -- Side Panel Buttons --
        btnOperation = Button(
            sideFrame, text = "Operation",
            font = ("Bahnschrift", 18, "bold"),
            fg="white",
            bg = "#1253a3",
            bd = 0,
            height=1,
            width = 13,
            justify=LEFT,
            anchor = W,
            #command = self.open_second_app)
            command = lambda: self.Indicate(operationIndicate, self.open_operation_page))
        btnOperation.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
        btnOperation.place(x = 25, y = 150)

        btnRun = Button(
            sideFrame, text = "Run",
            font = ("Bahnschrift", 18, BOLD),
            fg="white",
            bg = "#1253a3",
            bd = 0,
            height=1,
            width = 13,
            justify=LEFT,
            anchor = W,
            command= lambda: self.Indicate(runIndicate, self.open_run_page))
            #command = lambda: Indicate(runIndicate, RunPage))
        btnRun.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
        btnRun.place(x = 25, y = 200)

        btnDowntime = Button(
            sideFrame, text = "Downtime",
            font = ("Bahnschrift", 18, BOLD),
            fg="white",
            bg = "#1253a3",
            bd = 0,
            height=1,
            width = 13,
            justify=LEFT,
            anchor = W,
            command = lambda: self.Indicate(downtimeIndicate, self.open_downtime_page))
        btnDowntime.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
        btnDowntime.place(x = 25, y = 250)

        btnMonitor = Button(
            sideFrame, text = "Monitor",
            font = ("Bahnschrift", 18, BOLD),
            fg="white",
            bg = "#1253a3",
            bd = 0,
            height=1,
            width = 13,
            justify=LEFT,
            anchor = W,
            command = lambda: self.Indicate(monitorIndicate, self.open_monitor_page))
        btnMonitor.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
        btnMonitor.place(x = 25, y = 300)

        btnHistory = Button(
            sideFrame, text = "History Log",
            font = ("Bahnschrift", 18, BOLD),
            fg="white",
            bg = "#1253a3",
            bd = 0,
            height=1,
            width = 13,
            justify=LEFT,
            anchor = W,
            command = lambda: self.Indicate(historyIndicate, self.open_history_page))
        btnHistory.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
        btnHistory.place(x = 25, y = 350)

        btnMaintenance = Button(
            sideFrame, text = "Maintenance",
            font = ("Bahnschrift", 18, BOLD),
            fg="white",
            bg = "#1253a3",
            bd = 0,
            height=1,
            width = 13,
            justify=LEFT,
            anchor = W,
            command = lambda: self.Indicate(maintenanceIndicate, self.open_maintenance_page))
        btnMaintenance.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
        btnMaintenance.place(x = 25, y = 400)

        # Validate if Machine is from Oil Proff
        if Machine.division == "P1-Cooling" and Machine.section == "Oil Proof":
            btnSOC = Button(
                sideFrame, text = "SOC",
                font = ("Bahnschrift", 18, BOLD),
                fg="white",
                bg = "#1253a3",
                bd = 0,
                height=1,
                width = 13,
                justify=LEFT,
                anchor = W,
                command = lambda: self.Indicate(socIndicate, self.open_soc_page))
            btnSOC.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
            btnSOC.place(x = 25, y = 450)

            btnWeightMonitoring = Button(
                sideFrame, text = "Weight\nMonitoring",
                font = ("Bahnschrift", 18, BOLD),
                fg="white",
                bg = "#1253a3",
                bd = 0,
                height=2,
                width = 13,
                justify=LEFT,
                anchor = W,
                command = lambda: self.Indicate(dischargeIndicate, self.open_discharge_page))
            btnWeightMonitoring.pack(side = TOP, fill = BOTH, padx = 10, pady = 10)
            btnWeightMonitoring.place(x = 25, y = 500)

    def Indicate(self, lb, page):
        MainApp.HideIndicator()
        lb.config(bg = "White")
        page()

    def HideIndicator():
        operationIndicate.config(bg = "#1253a3")
        runIndicate.config(bg = "#1253a3")
        downtimeIndicate.config(bg = "#1253a3")
        monitorIndicate.config(bg = "#1253a3")
        #jogIndicate.config(bg = "#1253a3")
        historyIndicate.config(bg = "#1253a3")
        maintenanceIndicate.config(bg = "#1253a3")
        socIndicate.config(bg = "#1253a3")
        dischargeIndicate.config(bg = "#1253a3")

    def open_operation_page(self):
        MainApp.DeleteFrame(self.master)
        # Switch to the second tkinter file frame
        OperationPage.Run_OperationPage(self.master, self.switch_frame, runIndicate, MainApp.HideIndicator)

    def open_run_page(self):
        MainApp.DeleteFrame(self.master)
        RunPage.Run_RunPage(self.master, self.switch_frame)

    def open_downtime_page(self):
        MainApp.DeleteFrame(self.master)
        DowntimePage.Run_DowntimePage(self.master, self.switch_frame, root)

    def open_monitor_page(self):
        MainApp.DeleteFrame(self.master)
        MonitorPage.Run_MonitorPage(self.master, self.switch_frame, root)

    def open_maintenance_page(self):
        MainApp.DeleteFrame(self.master)
        MaintenancePage.Run_MaintenancePage(self.master, self.switch_frame, root)

    def open_history_page(self):
        MainApp.DeleteFrame(self.master)
        HistoryPage.Run_HistoryPage(self.master, self.switch_frame)

    def open_soc_page(self):
        MainApp.DeleteFrame(self.master)
        SOCPage.Run_SOCPage(self.master, self.switch_frame, root)
        
    def open_discharge_page(self):
        MainApp.DeleteFrame(self.master)
        DischargePage.Run_dischargePage(self.master, self.switch_frame, root)

    def switch_frame(self):
        # Switch back to the main frame
        self.pack()

    def DeleteFrame(self):
        for frame in self.winfo_children():
            frame.destroy()



if __name__ == "__main__":
    root = Tk()
    root.title("Human Machine Interface")
    root.geometry("1024x600")
    #root.attributes('-fullscreen', 'true')
    Machine.Machine.Machine_Details()


    # -- Side Panel --
    sideFrame = Frame(root, bg = "#1253a3")
    sideFrame.pack(side = LEFT, fill= BOTH)
    sideFrame.pack_propagate(False)
    sideFrame.configure(width = 250, height = 600)

    global operationIndicate, runIndicate, downtimeIndicate, monitorIndicate, jogIndicate, historyIndicate, socIndicate, dischargeIndicate
    
    # Indication
    operationIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    operationIndicate.place(x = 15, y = 150, width = 5, height = 46)

    runIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    runIndicate.place(x = 15, y = 200, width = 5, height = 46)

    downtimeIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    downtimeIndicate.place(x = 15, y = 250, width = 5, height = 46)

    monitorIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    monitorIndicate.place(x = 15, y = 300, width = 5, height = 46)

    historyIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    historyIndicate.place(x = 15, y = 350, width = 5, height = 46)

    maintenanceIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    maintenanceIndicate.place(x = 15, y = 400, width = 5, height = 46)

    socIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    socIndicate.place(x = 15, y = 450, width = 5, height = 46)

    dischargeIndicate = Label(sideFrame, text = '', bg = '#1253a3')
    dischargeIndicate.place(x = 15, y = 515, width = 5, height = 46)

    # -- Main Frame --
    mainFrame = Frame(root,  highlightbackground = "#1253a3", highlightthickness = 5)
    mainFrame.pack(side=LEFT, fill= BOTH, expand=1)
    mainFrame.pack_propagate(False)
    mainFrame.configure(height=600, width=1024)

    app = MainApp(mainFrame)
    app.pack()

    # messagebox.showinfo("Machine Information", "Please always check if the machine registered is correct.")

    root.mainloop()
import time
from socket import *
import datetime

from Database import module_v2 as db

BUFSIZE = 4096

class kvHostLink:
    addr = ()
    destfins = []
    srcfins = []
    port = 8500
    
    def __init__(self, host):
        self.addr = host, self.port

    def sendrecive(self, command):
        s = socket(AF_INET, SOCK_DGRAM)
        s.bind(('', self.port))
        s.settimeout(2)

        starttime = time.time()

        s.sendto(command, self.addr)
        #print("send:%r" % (command))
        rcvdata = s.recv(BUFSIZE)

        elapsedtime = time.time() - starttime
        #print ('receive: %r\t Length=%r\telapsedtime = %sms' % (rcvdata, len(rcvdata), str(elapsedtime * 1000)))
        #print()
        return rcvdata

    def mode(self, mode):
        senddata = 'M' + mode
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv

    def unittype(self):
        rcv = self.sendrecive("?k\r".encode())
        return rcv

    def errclr(self):
        senddata = 'ER'
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv

    def er(self):
        senddata = '?E'
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv

    def settime(self):
        dt_now = datetime.datetime.now()
        senddata = 'WRT ' + str(dt_now.year)[2:]
        senddata = senddata + ' ' + str(dt_now.month)
        senddata = senddata + ' ' + str(dt_now.day)
        senddata = senddata + ' ' + str(dt_now.hour)
        senddata = senddata + ' ' + str(dt_now.minute)
        senddata = senddata + ' ' + str(dt_now.second)
        senddata = senddata + ' ' + dt_now.strftime('%w')
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv
        
    def set(self, address):
        rcv = self.sendrecive(('ST ' + address + '\r').encode())
        return rcv

    def reset(self, address):
        rcv = self.sendrecive(('RS ' + address + '\r').encode())
        return rcv

    def sts(self, address, num):
        rcv = self.sendrecive(('STS ' + address + ' ' + str(num) + '\r').encode())
        return rcv

    def rss(self, address, num):
        rcv = self.sendrecive(('RSS ' + address + ' ' + str(num) + '\r').encode())
        return rcv

    def read(self, addresssuffix):
        rcv = self.sendrecive(('RD ' + addresssuffix + '\r').encode())
        return rcv

    def reads(self, addresssuffix, num):
        rcv = self.sendrecive(('RDS ' + addresssuffix + ' ' + str(num) + '\r').encode())
        return rcv

    def write(self, addresssuffix, data):
        rcv = self.sendrecive(('WR ' + addresssuffix + ' ' + data + '\r').encode())
        return rcv

    def writs(self, addresssuffix, num, data):
        rcv = self.sendrecive(('WRS ' + addresssuffix + ' ' + str(num) + ' ' + data + '\r').encode())
        return rcv


kv = kvHostLink('172.29.1.182')
data = kv.mode('1')


global flux_height, solder_height, solder_bath_temp, solder_heater_temp, flux_current_position, solder_current_position

def readPLC():
    flux_height = int(kv.read('DM10601.U').decode('utf-8'))
    solder_height = int(kv.read('DM10606.U').decode('utf-8'))

    solder_bath_temp =float(kv.read('DM10700.U').decode('utf-8')) * .100
    solder_heater_temp = float(kv.read('DM10710.U').decode('utf-8')) *.100

    solder_bath_temp = round(solder_bath_temp, 2)
    solder_heater_temp = round(solder_heater_temp, 2)

    flux_current_position = int(kv.read('DM400.U').decode('utf-8'))
    solder_current_position = int(kv.read('DM500.U').decode('utf-8'))

    db.Module.openquery()
    db.Module.query = "UPDATE RPI_ReadingPLC SET fldFluxHeight = ?, fldSolderHeight = ?, fldSolderBathTemp = ?, fldSolderHeaterTemp = ? WHERE fldId = 1"
    db.Module.parameter = (flux_height, solder_height, solder_bath_temp, solder_heater_temp)
    db.Module.opencommand()
    db.Module.conn.commit()
    db.Module.closeqry()




# print(flux_height)
# print(solder_height)
# print(solder_bath_temp)
# print(solder_heater_temp)
# print(flux_current_position)
# print(solder_current_position)
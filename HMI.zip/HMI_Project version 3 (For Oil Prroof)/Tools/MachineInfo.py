from datetime import datetime
from Database import module_v2 as db
from Database import moduleEMS as dbEMS
import socket
import os
import platform

class Machine:
    def Current_Machine():
        global machineId, machineName
        global hostname, ipAddress, pcUser
        hostname = socket.gethostname()
        ipAddress = socket.gethostbyname(hostname)
        pcUser = os.getlogin()
        
        if platform.system() != 'Windows':
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ipAddress = s.getsockname()[0]
        
        db.Module.openquery()
        db.Module.query = "SELECT * FROM RPI_CurrentMachine WHERE fldIPaddress = ? AND fldCurrentUser = ? AND fldHostname = ?"
        db.Module.parameter = ()
        parameter = list(db.Module.parameter)
        parameter.append(ipAddress)
        parameter.append(pcUser)
        parameter.append(hostname)
        db.Module.parameter = tuple(parameter)
        
        db.Module.opencommand()
        reader = db.Module.exeReader()
        if reader:
            for read in reader:
                machineId = read.fldMachineId
                machineName = read.fldMachineName
            
        else:
            Machine.UniqueID()

            db.Module.openquery()
            # db.Module.query = '''
            #     INSERT INTO RPI_CurrentMachine 
            #     (fldUniqueId, fldIPaddress, fldCurrentUser, 
            #     fldHostname) VALUES (?,?,?,?)
            # '''
            db.Module.query = '''
                INSERT INTO RPI_CurrentMachine
                (fldUniqueId, fldIPaddress, fldCurrentUser,
                fldHostname, fldMachineId, fldMachineName) 
                VALUES (?,?,?,?,?,?)
            '''
            db.Module.parameter = ()
            parameter = list(db.Module.parameter)
            parameter.append(userGeneratedID)
            parameter.append(ipAddress)
            parameter.append(pcUser)
            parameter.append(hostname)
            parameter.append("P3-R-SAMPLE3")
            parameter.append("S A M P L E 3")
            db.Module.parameter = tuple(parameter)

            db.Module.opencommand()
            db.Module.conn.commit()

            machineId = "P3-R-SAMPLE3"
            machineName = "S A M P L E 3"
            print(userGeneratedID)
            print(ipAddress)
            print(pcUser)
            print(hostname)


        db.Module.closeqry()

    def Machine_Details():
        global status, machineNo, model, division, section, manufacturer, leaseNo, fixedAsset, description, dateEndorsed, endorsedTo, incharge, machineType, serial
        
        dbEMS.Module.openquery()
        dbEMS.Module.query = "SELECT * FROM EMS_MachineMasterlist WHERE fldMachineID = ?"
        dbEMS.Module.parameter = machineId
        dbEMS.Module.opencommand()
        readDB = dbEMS.Module.exeReader()
        if readDB:
            for rows in readDB:
                status = rows.fldStatus
                machineNo = rows.fldMachineNo
                model = rows.fldModel
                division = rows.fldDivision
                section = rows.fldSection
                manufacturer = rows.fldManufacturer
                leaseNo = rows.fldLeaseNo
                fixedAsset = rows.fldFixedAsset
                description = rows.fldDescription
                dateEndorsed = rows.fldDateEndorsed
                endorsedTo = rows.fldEndorsedTo
                incharge = rows.fldIncharge
                machineType = rows.fldMachineType
                serial = rows.fldSerial
        
    def UniqueID():
        global user ,userCnt, userGeneratedID 

        dt = datetime.now()
        user = f"CU-{dt.strftime(f'%y%m%d')}"

        db.Module.query = "SELECT COUNT (fldId) AS mano FROM RPI_CurrentMachine WHERE fldUniqueId LIKE ?"
        db.Module.parameter = f'%{user}%'
        db.Module.openquery()
        db.Module.opencommand()
        readDB = db.Module.exeReader()
        if readDB:
            for rows in readDB:
                userCnt = int(rows.mano) + 1
            userGeneratedID = f"{user}-{userCnt:04}"
        db.Module.closeqry()
        return userGeneratedID


Machine.Current_Machine()
Machine.Machine_Details()
Machine.UniqueID()



from datetime import datetime
from tkinter import ttk
from tkinter import messagebox
from PIL import Image, ImageTk, ImageDraw
import time

from Database import module_v2 as db
from Pages import RunPage


# Meter Class
class Meter(ttk.Label):
    def __init__(self, parent, **kwargs):
        self.font = 'Bahnschrift 30 bold'
        self.foreground = 'Black'  
        self.background = '#f0f0ed' 
        self.size = 200
        self.indicatorcolor = '#1253a3'  
        self.hollowColor = 'Gray'
        self.arc = None
        self.running = False
        self.start_time = time.time()

        self.setup()

        super().__init__(parent, image=self.arc, compound='center', style='Meter.TLabel', **kwargs)

        self.update()

    # Function to draw arc and timer
    def setup(self):
        self.im = Image.new('RGBA', (1000, 1000))
        style = ttk.Style()
        style.configure('Meter.TLabel', font=self.font, foreground=self.foreground)
        if self.background:
            style.configure('Meter.TLabel', background=self.background)
        draw = ImageDraw.Draw(self.im)
        draw.arc((0, 0, 990, 990), 0, 360, self.hollowColor, 100)
        self.arc = ImageTk.PhotoImage(self.im.resize((self.size, self.size), Image.LANCZOS))

    global elapsed_time

    
    elapsed_time = 0

    # Update Function
    def update(self):
        if self.running:
            durationTime =  RunPage.cycleTime.cget("text") # Cycle Time

            elapsed_time = int(time.time() - self.start_time)
            scnd = 360 / durationTime
            angle = (elapsed_time % durationTime) * scnd + 90  # Calculate angle based on seconds
            self.im = Image.new('RGBA', (1000, 1000))
            draw = ImageDraw.Draw(self.im)
            draw.arc((0, 0, 990, 990), 0, 360, self.hollowColor, 100)

            if elapsed_time == 0:
                draw.arc((0, 0, 990, 990), 0, 360, self.indicatorcolor, 100)
                self.arc = ImageTk.PhotoImage(self.im.resize((self.size, self.size), Image.LANCZOS))
                self.configure(image=self.arc, text=f"{durationTime // 60:02}:{durationTime % 60:02}")  # Display elapsed time
            else:
                draw.arc((0, 0, 990, 990), 90, angle, self.indicatorcolor, 100)
                self.arc = ImageTk.PhotoImage(self.im.resize((self.size, self.size), Image.LANCZOS))
                self.configure(image=self.arc, text=f"{elapsed_time // 60:02}:{elapsed_time % 60:02}")  # Display elapsed time

                productQTY_Counter()
            
            self.after(1000, self.update)  # Update every second

            if elapsed_time == durationTime:
                self.start_time = time.time()
                self.update()

                # RunPage
                count = int(RunPage.targetQty.cget("text")) + 1
                RunPage.targetQty.config(text=str(count))
                
    def start_timer(self):
        if not self.running:
            if RunPage.uniqueId != "":
                global actual_count
                actual_count = 0
                self.start_time = time.time()
                self.running = True
                self.update()
                self.configure(image=self.arc, text=f"{0 // 60:02}:{0 % 60:02}")
            
            else:
                messagebox.showerror("Item Not Found","Please set Production Data first!")

    def stop_timer(self):
        if RunPage.uniqueId != "":
        
            self.running = False

            msg = messagebox.askyesno("Save Data", "Please select yes to save data.")
            dt = datetime.now()
            if msg == 1:
                actual_qty = RunPage.actualQty.get()
                status = RunPage.txtStatus.get()
                
                if actual_qty.isdigit():
                    if status != "":

                        db.Module.openquery()
                        db.Module.query = "UPDATE RPI_Operation SET fldActualQty = ?, fldTarget = ?, fldTotalQty = ?, fldStatus = ?, fldStopTime = ? WHERE fldUniqueId = ?"
                        
                        db.Module.parameter = ()
                        parameter = list(db.Module.parameter)
                        parameter.append(actual_qty)
                        parameter.append(RunPage.targetQty.cget("text"))
                        parameter.append(actual_qty)
                        parameter.append(status)
                        parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
                        parameter.append(RunPage.uniqueId)
                        db.Module.parameter = tuple(parameter)

                        db.Module.opencommand()
                        db.Module.conn.commit()
                        db.Module.closeqry()

                        RunPage.uniqueId = ""
                        RunPage.programNumber.config(text = "---")
                        RunPage.modelNumber.config(text = "---")
                        RunPage.modelType.config(text = "---")
                        RunPage.shopOrder.config(text = "---")
                        RunPage.productQty.config(text = "---")
                        RunPage.cycleTime.config(text = "---")
                        RunPage.status.config(text = "---")
                        RunPage.startTime.config(text = "00:00:00 AA \n00/00/0000")
                        RunPage.targetQty.config(text = 0)

                    else:
                        messagebox.showerror("Invalid Input", "Please select status")
                        
                else:
                    messagebox.showerror("Invalid Input", "Please enter numeric value only")
        

    def reset_timer(self):
        self.running = False
        self.start_time = 0
        self.update()
        
        RunPage.targetQty.config(text = "0")


actual_count = 0
def productQTY_Counter():
    global current_count, actual_count
    db.Module.openquery()
    db.Module.query = "SELECT COUNT(fld_count) AS cnt FROM RPI_Count"
    db.Module.parameter = None
    db.Module.opencommand()
    read = db.Module.exeReader()
    if read:
        for row in read:
            bilang = int(RunPage.prductlQty.cget("text"))

            current_count = int(row.cnt)
            if current_count != actual_count:
                RunPage.prductlQty.config(text=str(bilang + 1))
                actual_count = row.cnt
                

def run_Oras(master):
    meter = Meter(master, padding=0)
    meter.pack()
    


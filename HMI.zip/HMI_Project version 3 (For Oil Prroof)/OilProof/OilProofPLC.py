# Oil Proof IP Address: 172.29.17.40
from datetime import datetime
from socket import *
from Database import module_v2 as db
from Tools import MachineInfo
import time

#from Database import module_v2 as db

BUFSIZE = 4096

class kvHostLink:
    addr = ()
    destfins = []
    srcfins = []
    port = 8500
    
    def __init__(self, host):
        self.addr = host, self.port

    def sendrecive(self, command):
        s = socket(AF_INET, SOCK_DGRAM)
        s.bind(('', self.port))
        s.settimeout(2)

        starttime = time.time()

        s.sendto(command, self.addr)
        #print("send:%r" % (command))
        rcvdata = s.recv(BUFSIZE)

        elapsedtime = time.time() - starttime
        #print ('receive: %r\t Length=%r\telapsedtime = %sms' % (rcvdata, len(rcvdata), str(elapsedtime * 1000)))
        #print()
        return rcvdata

    def mode(self, mode):
        senddata = 'M' + mode
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv

    def unittype(self):
        rcv = self.sendrecive("?k\r".encode())
        return rcv

    def errclr(self):
        senddata = 'ER'
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv

    def er(self):
        senddata = '?E'
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv

    def settime(self):
        dt_now = datetime.datetime.now()
        senddata = 'WRT ' + str(dt_now.year)[2:]
        senddata = senddata + ' ' + str(dt_now.month)
        senddata = senddata + ' ' + str(dt_now.day)
        senddata = senddata + ' ' + str(dt_now.hour)
        senddata = senddata + ' ' + str(dt_now.minute)
        senddata = senddata + ' ' + str(dt_now.second)
        senddata = senddata + ' ' + dt_now.strftime('%w')
        rcv = self.sendrecive((senddata + '\r').encode())
        return rcv
        
    def set(self, address):
        rcv = self.sendrecive(('ST ' + address + '\r').encode())
        return rcv

    def reset(self, address):
        rcv = self.sendrecive(('RS ' + address + '\r').encode())
        return rcv

    def sts(self, address, num):
        rcv = self.sendrecive(('STS ' + address + ' ' + str(num) + '\r').encode())
        return rcv

    def rss(self, address, num):
        rcv = self.sendrecive(('RSS ' + address + ' ' + str(num) + '\r').encode())
        return rcv

    def read(self, addresssuffix):
        rcv = self.sendrecive(('RD ' + addresssuffix + '\r').encode())
        return rcv

    def reads(self, addresssuffix, num):
        rcv = self.sendrecive(('RDS ' + addresssuffix + ' ' + str(num) + '\r').encode())
        return rcv

    def write(self, addresssuffix, data):
        rcv = self.sendrecive(('WR ' + addresssuffix + ' ' + data + '\r').encode())
        return rcv

    def writs(self, addresssuffix, num, data):
        rcv = self.sendrecive(('WRS ' + addresssuffix + ' ' + str(num) + ' ' + data + '\r').encode())
        return rcv


kv = kvHostLink('172.29.17.40') #IP Oil Proof
data = kv.mode('1')

global A_tankTemp, B_tankTemp, A_pumpRevolution, B_pumpRevolution, A_pumpPres, B_pumpPres, A_motionVal, B_motionVal, A_returnVal, B_returnVal, mixRise
global A_tankLiquid, B_tankLiquid, A_tankRoom, B_tankRoom, A_hoseTemp, B_hoseTemp, mixingHead

def Parameters():
    # Monitor
    #A_tankTemp = float(kv.read('W034C.S'))
    #B_tankTemp = float(kv.read('W034D.S'))

    A_tankTemp = round(float(kv.read('W0259.S')) * .1, 2) 
    B_tankTemp = round(float(kv.read('W0279.S')) * .1, 2)

    A_pumpRevolution = int(kv.read('D207.S'))
    B_pumpRevolution = int(kv.read('D208.S'))

    A_pumpPres = round(float(kv.read('D201.S')) * .01, 2)
    B_pumpPres = round(float(kv.read('D202.S')) * .01, 2)

    A_motionVal = round(float(kv.read('D209.S')) * .001, 3)
    B_motionVal = round(float(kv.read('D210.S')) * .001, 3)

    A_returnVal = round(float(kv.read('D211.S')) * .1, 2)
    B_returnVal = round(float(kv.read('D212.S')) * .1, 2)

    mixRise = int(kv.read('D215.S'))

    # Details of Temp
    A_tankLiquid = round(float(kv.read('W0259.S')) * .1, 2)
    B_tankLiquid = round(float(kv.read('W0279.S')) * .1, 2)

    # A_tankLiquid = float(kv.read('DM268.L'))
    # B_tankLiquid = float(kv.read('DM272.L'))

    A_tankRoom = round(float(kv.read('W0289.S')) * .1, 2)
    B_tankRoom = round(float(kv.read('W0274.S')) * .1, 2)

    A_hoseTemp = round(float(kv.read('W0240.S')) * .1, 2)
    B_hoseTemp = round(float(kv.read('W0260.S')) * .1, 2)

    mixingHead = round(float(kv.read('W0284.S')) * .1, 2)

    trigger1 = int(kv.read('M304'))
    trigger2 = int(kv.read('M303'))
    trigger3 = int(kv.read('M598'))
    trigger4 = int(kv.read('Y1015'))
    
    if trigger4 == 1:
        status = "Running"
    elif trigger1 == 1 and trigger2 == 1 and trigger3 == 1:
        status = "Standby"
    

    db.Module.openquery()
    db.Module.query = '''
        INSERT INTO RPI_OilProofMonitoring (
            fldMachineId, fldStatus,
            fldTankTempA, fldTankTempB, fldPumpRevolutionA, fldPumpRevolutionB,
            fldPumpPresA, fldPumpPresB, fldMotionValA, fldMotionValB, 
            fldReturnValA, fldReturnValB, fldMixRise, 
            fldTankLiquidA, fldTankLiquidB, fldTankRoomA, fldTankRoomB,
            fldHoseTempA, fldHoseTempB, fldMixingHead, fldDateRegistered
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) '''
    db.Module.parameter = ()
    parameter = list(db.Module.parameter)
    parameter.append(MachineInfo.machineId)
    parameter.append(status)
    parameter.append(A_tankTemp)
    parameter.append(B_tankTemp)
    parameter.append(A_pumpRevolution)
    parameter.append(B_pumpRevolution)
    parameter.append(A_pumpPres)
    parameter.append(B_pumpPres)
    parameter.append(A_motionVal)
    parameter.append(B_motionVal)
    parameter.append(A_returnVal)
    parameter.append(B_returnVal)
    parameter.append(mixRise)
    parameter.append(A_tankLiquid)
    parameter.append(B_tankLiquid)
    parameter.append(A_tankRoom)
    parameter.append(B_tankRoom)
    parameter.append(A_hoseTemp)
    parameter.append(B_hoseTemp)
    parameter.append(mixingHead)
    parameter.append(datetime.now())
    db.Module.parameter = tuple(parameter)

    db.Module.opencommand()
    db.Module.conn.commit()
    db.Module.closeqry()

    


    






from datetime import datetime
import textwrap
from tkinter import *
from tkinter import messagebox
from tkinter.font import BOLD
from tkinter.ttk import Treeview

from Database import module_v2 as db
from Tools import MachineInfo


class SOCApp(Frame):
    def __init__(self, master, switch_frame, root):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame
        self.root = root

        SOCApp.SocPage(self)

    def SocPage(self):
        global frameSOC
        frameSOC = Frame(self)
        frameSOC.pack(side=TOP, fill= BOTH, expand=1, padx = 10, pady = 10)
        frameSOC.pack_propagate(False)
        frameSOC.configure(height=500, width=1024)

        # Page Title
        lblSocTitle = Label(frameSOC, text = "Start of Operation Checklist ", font = ("Bahnschrift", 20, BOLD), justify = LEFT, fg="Black", anchor = "w")
        lblSocTitle.pack(side = TOP, fill= BOTH)

        dt = datetime.now()
        # Tree View
        frameSocList = Frame(frameSOC)

        treeviewItem = []

        db.Module.openquery()
        db.Module.query = "SELECT * FROM RPI_OilProof_SOC WHERE fldMachineId = ? AND fldDate LIKE ? ORDER BY fldDate DESC"
        db.Module.parameter = ()
        parameter = list(db.Module.parameter)
        parameter.append(MachineInfo.machineId)
        parameter.append(f"%{dt.strftime(f'%y-%m')}%")
        db.Module.parameter = tuple(parameter)
        db.Module.opencommand()
        reader = db.Module.exeReader()
        if reader:
            for row in reader:
                old_dt = datetime.strptime(row.fldDate, f'%Y-%m-%d')
                new_dt = old_dt.strftime(f'%m-%d')
                item = [
                    new_dt,
                    row.fldAirPressure,
                    row.fldTankUpperValve,
                    row.fldLiquidWasteTank,
                    row.fldWashingTank,
                    row.fldEpoxyTankA,
                    row.fldEpoxyTankB,
                    row.fldMixerHeadTemp,
                    row.fldDischargeTubeTemp,
                    row.fldDischargeTubeDirt,
                    row.fldMixingChamber,
                    row.fldMixingRotor,
                    row.fldTankMotor,
                    row.fldMixerHeadLubrication,
                    row.fldPushButton,
                    row.fldWashingAirPressure,
                    row.fldOperator,
                ]
                treeviewItem.append(item)
        db.Module.closeqry()

        cols = ('date', 'airPressure', 'tankUpperValve', 'liquidWasteTank', 
            'washingTank', 'epoxyTankA', 'epoxyTankB', 'mixerHeadTemp',
            'dischargeTubeTemp', 'dischargeTubeDirt', 'mixerChamber', 'mixingRotor', 'Tank Motor',
            'mixerHeadLub', 'pushButton', 'washingAirPressureGauge', 'operator')

        text_soc = ('Date', 'Air Pressure', 'Tank Upper Valve', 'Liquid Waste Tank', 
            'Washing Tank', 'Epoxy Tank A', 'Epoxy Tank B', 'Mixer Head (Temp.)',
            'Discharge Tube (Temp.)', 'Discharge Tube (Dirt)', 'Mixer Chamber', 'Mixing Rotor', 'Tank Motor',
            'Mixer Head (Lubrication)', 'Push Button', 'Washing Air Pressure Gauge', 'Operator')

        size = (55, 75, 100, 110, 85, 85, 85, 115, 135, 120, 90, 80, 75, 140, 80, 157, 150)

        tv_SOC = Treeview(frameSocList, columns=cols, show='headings')

        soc_cnt = 0
        for x in cols:
            tv_SOC.column(x, width=size[soc_cnt], anchor=CENTER)
            tv_SOC.heading(x, text=text_soc[soc_cnt] )
            soc_cnt += 1

        for socItem in treeviewItem:
            tv_SOC.insert('', END, values=socItem)

        def Item_Selected(event):
            for selected_item in tv_SOC.selection():
                item = tv_SOC.item(selected_item)
                record = item['values']

        tv_SOC.bind('<<TreeviewSelect>>', Item_Selected)
        tv_SOC.pack(side=TOP, fill=BOTH, expand = True)


        xScroll = Scrollbar(frameSocList, orient=HORIZONTAL, command=tv_SOC.xview)
        tv_SOC.configure(xscrollcommand=xScroll.set)
        xScroll.pack(side=BOTTOM, fill = X)



        frameSocList.pack(side=TOP, fill= BOTH, expand = True)
        

        btnSOCFrame = Frame(self)
        btnSOCFrame.pack(side = BOTTOM, fill = X, expand= False)

        btnSOC = Button(btnSOCFrame, text = "Submit SOC", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command=self.Report_SOC)
        btnSOC.pack(side = LEFT, padx=10, pady=10)

    def Report_SOC(self):
        global submit_window
        submit_window=Toplevel(self.root)
        submit_window.geometry("820x555")
        submit_window.title("Submit SOC")
        submit_window.resizable(0,0)
        submit_window.attributes('-topmost', 'true')

        equipmentFrame = Frame(submit_window)
        equipmentFrame.pack(side=TOP, fill=BOTH, expand=False)

        label = Label(equipmentFrame, text=f'Equipment Name:', font=("Bahnschrift", 10), justify= LEFT, anchor=W)
        label.grid(row=0, column=0, sticky=NSEW, padx=(0, 15))

        equipmentName = Label(equipmentFrame, text=MachineInfo.machineName, font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        equipmentName.grid(row=0, column=1, sticky=NSEW, padx=(0, 15), columnspan=2)


        reportFrame = Frame(submit_window)
        reportFrame.pack(side=TOP, fill=BOTH, expand=True)  
        
        label = Label(reportFrame, text=f'No.', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=0, sticky=NSEW,padx=(0, 15), pady=(15, 0))

        label = Label(reportFrame, text='Checked Part', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=1, sticky=NSEW, padx=(0, 15), pady=(15, 0))

        label = Label(reportFrame, text='Checked Item', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=2, sticky=NSEW, padx=(0, 15), pady=(15, 0))

        label = Label(reportFrame, text='Checked Method', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=3, sticky=NSEW, padx=(0, 15), pady=(15, 0))
       
        label = Label(reportFrame, text='Standard', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=4, sticky=NSEW, padx=(0, 15), pady=(15, 0))

        label = Label(reportFrame, text='Check Result', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=5, sticky=NSEW, padx=(0, 15), pady=(15, 0))


        list_checkedPart = ['Air Pressure', 'Tank Upper Valve', 'Liquid Waste Tank', 
            'Washing Tank', 'Epoxy Tank A', 'Epoxy Tank B', 'Mixer Head',
            'Discharge Tube', 'Discharge Tube', 'Mixer Chamber', 'Mixing Rotor', 'Tank Motor',
            'Mixer Head', 'Push Button', 'Washing Air Pressure Gauge']
        
        list_checkedItem = ['Air Pressure', 'Valve Position', 'Liquid Amount',
            'Liquid Amount', 'Tank Liquid Temp.', 'Tank Liquid Temp.', 'Temperature', 
            'Temperature', 'Dirt in Tube', 'Obstruction', 'Dirt', 'Motor Revolution',
            'Lubrication', 'Emergency Stop Button', 'Air Pressure']

        list_checkMethod = ['Pressure Gauge', 'Visual', 'Visual', 'Visual', 'Thermometer',
            'Thermometer', 'Thermometer', 'Thermometer', 'Visul', 'Cleaning',
            'Visual', 'Visual', 'Visual', 'Testing', 'Visual']
        list_standard = ['0.4 - 0.6 MPA', 'Open', '2/3 below', '1/4 above', 
            '50±5°C', '40±5°C', '45±5°C', 'See Process specs', 'No Hardened Epoxy',
            'Daily Cleaning/Checking', 'No Leak', 'Upper limit 4200 rpm',
            'New Grease, Weekly Check', 'MC will not operate when pressed', '0.14-0.20MPA']



        for x in range(1, 16):
            line = Canvas(reportFrame, height=2, bg = "Gray")
            line.grid(row=(x * 2) - 1, column=0, columnspan=6, sticky=NSEW)

            label = Label(reportFrame, text=x, font=("Bahnschrift", 10), justify= LEFT, anchor=W)
            label.grid(row= x * 2, column=0, sticky=NSEW, padx=(0, 15))

        row = 2
        for x in list_checkedPart:
            label = Label(reportFrame, text=x, font=("Bahnschrift", 10), justify= LEFT, anchor=W)
            label.grid(row=row, column=1, sticky=NSEW, padx=(0, 15))
            row += 2

        row2 = 2
        for x in list_checkedItem:
            label = Label(reportFrame, text=x, font=("Bahnschrift", 10), justify= LEFT, anchor=W)
            label.grid(row=row2, column=2, sticky=NSEW, padx=(0, 15))
            row2 += 2

        row3 = 2
        for x in list_checkMethod:
            label = Label(reportFrame, text=x, font=("Bahnschrift", 10), justify= LEFT, anchor=W)
            label.grid(row=row3, column=3, sticky=NSEW, padx=(0, 15))
            row3 += 2
        
        row4 = 2
        for x in list_standard:
            label = Label(reportFrame, text=x, font=("Bahnschrift", 10), justify= LEFT, anchor=W)
            label.grid(row=row4, column=4, sticky=NSEW, padx=(0, 15))
            row4 += 2

       
        #region -- TEXTBOX --
        global txt_airPressure, txt_tankUpperValve, txt_liquidWasteTank, txt_washingTank
        global txt_epoxyTankA, txt_epoxyTankB, txt_mixerHeadTemp
        global txt_dischargeTubeTemp, txt_dischageTubeDirt, txt_mixingChamber
        global txt_mixingRotor, txt_tankMotor, txt_mixerheadLubrication, txt_pushButton, txt_washingAirPressureGauge, txt_operator

        txt_airPressure =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_airPressure.grid(row=2, column=5, sticky=N)

        txt_tankUpperValve =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_tankUpperValve.grid(row=4, column=5, sticky=N)

        txt_liquidWasteTank =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_liquidWasteTank.grid(row=6, column=5, sticky=N)

        txt_washingTank =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_washingTank.grid(row=8, column=5, sticky=N)

        txt_epoxyTankA =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_epoxyTankA.grid(row=10, column=5, sticky=N)

        txt_epoxyTankB =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_epoxyTankB.grid(row=12, column=5, sticky=N)

        txt_mixerHeadTemp =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_mixerHeadTemp.grid(row=14, column=5, sticky=N)

        txt_dischargeTubeTemp =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_dischargeTubeTemp.grid(row=16, column=5, sticky=N)

        txt_dischageTubeDirt =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_dischageTubeDirt.grid(row=18, column=5, sticky=N)

        txt_mixingChamber =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_mixingChamber.grid(row=20, column=5, sticky=N)

        txt_mixingRotor =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_mixingRotor.grid(row=22, column=5, sticky=N)

        txt_tankMotor =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_tankMotor.grid(row=24, column=5, sticky=N)

        txt_mixerheadLubrication =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_mixerheadLubrication.grid(row=26, column=5, sticky=N)

        txt_pushButton =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_pushButton.grid(row=28, column=5, sticky=N)

        txt_washingAirPressureGauge =  Entry(reportFrame, width = 10, font = ("Bahnschrift", 10), fg="Black")
        txt_washingAirPressureGauge.grid(row=30, column=5, sticky=N)
        #endregion

        line = Canvas(reportFrame, height=2, bg = "Gray")
        line.grid(row=31, column=0, columnspan=6, sticky=NSEW)


        btn_Frame = Frame(submit_window)
        btn_Frame.pack(side = BOTTOM, fill = X, expand= False, pady=(0,30))

        label = Label(btn_Frame, text="Operator's Name:", font=("Bahnschrift", 10, BOLD), justify= RIGHT, anchor=E)
        #label.grid(row=32, column=4, sticky=NSEW, padx=(0, 15), pady=(5, 0))
        label.pack(side = LEFT)

        txt_operator =  Entry(btn_Frame, width = 25, font = ("Bahnschrift", 10), fg="Black")
        #txt_operator.grid(row=32, column=5, sticky=N, pady=(5, 0))
        txt_operator.pack(side = LEFT)

        btnSubmit = Button(btn_Frame, text = "Submit", font = ("Bahnschrift", 10, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, justify=CENTER, width=12, command=self.Submit_SOC)
        btnSubmit.pack(side = RIGHT, padx=10)

    def Submit_SOC(self):
        air_pressure = txt_airPressure.get().upper()
        tank_upper_valve = txt_tankUpperValve.get().upper()
        liquid_waste_tank = txt_liquidWasteTank.get().upper()
        washing_tank = txt_washingTank.get().upper()
        epoxy_tank_a = txt_epoxyTankA.get().upper()
        epoxy_tank_b = txt_epoxyTankB.get().upper()
        mixer_head_temp = txt_mixerHeadTemp.get().upper()
        discharge_tube_temp = txt_dischargeTubeTemp.get().upper()
        discharge_tube_dirt = txt_dischageTubeDirt.get().upper()
        mixing_chamber = txt_mixingChamber.get().upper()
        mixing_rotor = txt_mixingRotor.get().upper()
        tank_motor = txt_tankMotor.get().upper()
        mixer_head_lubrication = txt_mixerheadLubrication.get().upper()
        push_button = txt_pushButton.get().upper()
        washing_air_pressure_gauge = txt_washingAirPressureGauge.get().upper()
        operator = txt_operator.get().upper()

        #if air_pressure.isnumeric() and not tank_upper_valve.isnumeric() and not liquid_waste_tank.isnumeric() and not washing_tank.isnumeric() and epoxy_tank_a.isnumeric and epoxy_tank_b.isnumeric() and mixer_head_temp.isnumeric() and discharge_tube_temp.isnumeric() and not discharge_tube_dirt.isnumeric() and not mixing_chamber.isnumeric() and not mixing_rotor.isnumeric() and not tank_motor.isnumeric() and mixer_head_lubrication.isnumeric() and not push_button.isnumeric and washing_air_pressure_gauge.isnumeric():
        
        today = datetime.now()

        db.Module.openquery()
        db.Module.query = "SELECT * FROM RPI_OilProof_SOC WHERE fldDate = ? AND fldMachineId = ?"
        db.Module.parameter = ()
        parameter = list(db.Module.parameter)
        parameter.append(today.strftime(f'%Y-%m-%d'))
        parameter.append(MachineInfo.machineId)
        db.Module.parameter = tuple(parameter)
        db.Module.opencommand()
        readDB = db.Module.exeReader()
        if not readDB:
            if not operator == "":
                Generate_Unique_ID()
                
                db.Module.openquery()
                db.Module.query = '''
                    INSERT INTO RPI_OilProof_SOC
                    (fldUniqueId, fldMachineId, fldMachineNo, fldDate, 
                    fldAirPressure, fldTankUpperValve, fldLiquidWasteTank, 
                    fldWashingTank, fldEpoxyTankA, fldEpoxyTankB, fldMixerHeadTemp,
                    fldDischargeTubeTemp, fldDischargeTubeDirt, fldMixingChamber,
                    fldMixingRotor, fldTankMotor, fldMixerHeadLubrication,
                    fldPushButton, fldWashingAirPressure, fldOperator,
                    fldDateRegistered)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                '''
                db.Module.parameter = ()
                parameter = list(db.Module.parameter)
                parameter.append(socGeneratedControlNo)
                parameter.append(MachineInfo.machineId)
                parameter.append(MachineInfo.machineNo)
                parameter.append(today.strftime(f'%Y-%m-%d'))
                parameter.append(air_pressure)
                parameter.append(tank_upper_valve)
                parameter.append(liquid_waste_tank)
                parameter.append(washing_tank)
                parameter.append(epoxy_tank_a)
                parameter.append(epoxy_tank_b)
                parameter.append(mixer_head_temp)
                parameter.append(discharge_tube_temp)
                parameter.append(discharge_tube_dirt)
                parameter.append(mixing_chamber)
                parameter.append(mixing_rotor)
                parameter.append(tank_motor)
                parameter.append(mixer_head_lubrication)
                parameter.append(push_button)
                parameter.append(washing_air_pressure_gauge)
                parameter.append(operator)
                parameter.append(today)
                db.Module.parameter = tuple(parameter)
                db.Module.opencommand()
                db.Module.conn.commit()
                #db.Module.closeqry()

                self.destroy()
                Run_SOCPage(self.master, self.switch_frame, self.root)
            else:
                submit_window.attributes('-topmost', 'false')
                messagebox.showerror("Missing Fields", "Please fill operator's name!")
                submit_window.attributes('-topmost', 'true')
        else:
            submit_window.attributes('-topmost', 'false')
            messagebox.showinfo("SOC Already Submitted", "Start of Operation Checklist for this day is already submitted.")
            submit_window.attributes('-topmost', 'true')
            
        db.Module.closeqry()
            

        # print(air_pressure)
        # print(tank_upper_valve)
        # print(liquid_waste_tank)
        # print(washing_tank)
        # print(epoxy_tank_a)
        # print(epoxy_tank_b)
        # print(mixer_head_temp)
        # print(discharge_tube_temp)
        # print(discharge_tube_dirt)
        # print(mixing_chamber)
        # print(mixing_rotor)
        # print(tank_motor)
        # print(mixer_head_lubrication)
        # print(push_button)
        # print(washing_air_pressure_gauge)
        # print(operator)

def Generate_Unique_ID():
    global socGeneratedControlNo

    dt = datetime.now()
    soc = f"SOC-{dt.strftime(f'%y%m%d')}"

    db.Module.query = "SELECT COUNT (fldId) AS mano FROM RPI_OilProof_SOC WHERE fldUniqueId LIKE ?"
    db.Module.parameter = f'%{soc}%'
    db.Module.openquery()
    db.Module.opencommand()
    readDB = db.Module.exeReader()
    if readDB:
        for rows in readDB:
            socCnt = int(rows.mano) + 1
        socGeneratedControlNo = f"{soc}-{socCnt:04}"
    db.Module.closeqry()
    return socGeneratedControlNo 

def Run_SOCPage(master, switch_frame, root):
    app = SOCApp(master, switch_frame, root)
    app.pack(side= LEFT, fill = BOTH, expand=True)
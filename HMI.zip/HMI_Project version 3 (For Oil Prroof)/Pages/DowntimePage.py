from datetime import datetime
from tkinter import *
from tkinter import ttk
from tkinter.font import BOLD
from tkinter.ttk import Combobox
from tkcalendar import * # for Datetime picker

# Database
from Database import moduleEMS as dbEMS

from Tools import MachineInfo

class Downtime(Frame):
    def __init__(self, master, switch_frame, root):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame
        self.root = root

        Downtime.Current_Down(self)

    def Current_Down(self):
        global downtimeFrame

        downtimeFrame = Frame(self)
        downtimeFrame.pack(side=TOP, fill=BOTH, expand=True, padx=10, pady=10)
        downtimeFrame.pack_propagate(False)
        downtimeFrame.configure(height=500, width=1024)

        #region -- Current Down -- 
        header = Frame(downtimeFrame, bg = 'SteelBlue')
        header.pack(side = TOP, fill = X, expand= False)

        troubleCanvas = Canvas(downtimeFrame)
        troubleCanvas.pack(side = LEFT, fill= BOTH, expand=TRUE)
        troubleCanvas.pack_propagate(False)
        troubleCanvas.configure(width = 1000, height = 400)

        scrollbar = Scrollbar(downtimeFrame, orient=VERTICAL, command=troubleCanvas.yview)
        dataFrame = Frame(troubleCanvas)

        dataFrame.bind(
            "<Configure>",
            lambda e: troubleCanvas.configure(
                scrollregion=troubleCanvas.bbox("all")
            )
        )

        troubleCanvas.create_window((0, 0), window=dataFrame, anchor=NW)

        troubleCanvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=RIGHT, fill=Y)

        def Down_Counter():
            dbEMS.Module.openquery()
            dbEMS.Module.query = '''
        WITH MachineData AS (
            SELECT
                tln.fldMachineID,
                mml.fldMachineName,
                mml.fldDivision,
                mml.fldSection,
                tln.fldStatus,
                tln.fldPE,
                tln.fldControlNumber,
                tln.fldDetails,
                tln.fldTroubleType,
                tln.fldInterval,
                tln.fldDate,
                tln.fldActualStart,
                tln.fldID,
                ROW_NUMBER() OVER(PARTITION BY mml.fldMachineID ORDER BY tln.fldDate DESC) AS rn
            FROM EMS_TroubleLogNew AS tln
            FULL OUTER JOIN EMS_MachineMasterlist AS mml ON tln.fldMachineID = mml.fldMachineID
            WHERE tln.fldDate LIKE '20%'
            AND mml.fldDivision = ?
            AND mml.fldSection = ?
            AND mml.fldMachineID = ?
            AND (mml.fldStatus = ? OR mml.fldStatus = ? OR mml.fldStatus = ?)
        )
        SELECT *
        FROM
        (SELECT COUNT (fldMachineName) AS Machine FROM MachineData WHERE rn = 1 ) a,
        (SELECT COUNT (fldStatus) AS Down FROM MachineData WHERE fldStatus = ?) b,
        (SELECT COUNT (fldStatus) AS Monitoring FROM MachineData WHERE rn = 1 AND fldStatus = ? ) c,
        (SELECT COUNT (fldStatus) AS ForRepair FROM MachineData WHERE rn = 1 AND fldStatus = ?) d
            '''
            dbEMS.Module.parameter = ()
            parameter =  list(dbEMS.Module.parameter)
            parameter.append(MachineInfo.division)
            parameter.append(MachineInfo.section)
            parameter.append(MachineInfo.machineId)
            parameter.append("Down")
            parameter.append("Monitoring")
            parameter.append("For Repair")
            parameter.append("Down")
            parameter.append("Monitoring")
            parameter.append("For Repair")
            dbEMS.Module.parameter = tuple(parameter)

            dbEMS.Module.opencommand()
            downReader = dbEMS.Module.exeReader()
            if downReader:
                for row in downReader:
                    downFrame = Frame(header, bg = 'SteelBlue')
                    downFrame.pack(side = TOP, fill = Y, expand = False)

                    AllMachine = Label(downFrame, text=f'All Machine: {row.Machine}', justify= CENTER, anchor=CENTER, font=("Bahnschrift", 12, BOLD), height=2 , bg = 'SteelBlue', fg = 'White')
                    AllMachine.grid(row=0, column=0, sticky=NSEW, padx=(0, 20))

                    line1 = Label(downFrame, text=f'', justify= CENTER, anchor=CENTER, bg = '#D04848', width=2)
                    line1.grid(row=0, column=1)

                    down = Label(downFrame, text=f'Down: {row.Down}', justify= CENTER, font=("Bahnschrift", 12, BOLD), anchor=CENTER, bg = 'SteelBlue', fg = 'White')
                    down.grid(row=0, column=2, sticky=NSEW, padx=(0, 15))

                    line2 = Label(downFrame, text=f'', justify= CENTER, anchor=CENTER, bg = '#0F2C67', width=2)
                    line2.grid(row=0, column=3)

                    monitoring = Label(downFrame, text=f'Monitoring: {row.Monitoring}', font=("Bahnschrift", 12, BOLD), justify= CENTER, anchor=CENTER, bg = 'SteelBlue', fg = 'White')
                    monitoring.grid(row=0, column=4, sticky=NSEW, padx=(0, 15))

                    line3 = Label(downFrame, text=f'', justify= CENTER, anchor=CENTER, bg = '#F3950D', width=2)
                    line3.grid(row=0, column=5)

                    repair = Label(downFrame, text=f'For Repair: {row.ForRepair}', font=("Bahnschrift", 12, BOLD), justify= CENTER, anchor=CENTER, bg = 'SteelBlue', fg = 'White')
                    repair.grid(row=0, column=6, sticky=NSEW, padx=(0, 15))

        def Machine_Status():
            dbEMS.Module.openquery()
            dbEMS.Module.query =  '''
        WITH MachineData AS (
            SELECT
                tln.fldMachineID,
                mml.fldMachineName,
                mml.fldDivision,
                mml.fldSection,
                tln.fldStatus,
                tln.fldPE,
                tln.fldControlNumber,
                tln.fldDetails,
                tln.fldTroubleType,
                tln.fldInterval,
                tln.fldDate,
                tln.fldActualStart,
                tln.fldID,
                ROW_NUMBER() OVER(PARTITION BY mml.fldMachineID ORDER BY tln.fldDate DESC) AS rn
            FROM EMS_TroubleLogNew AS tln
            FULL OUTER JOIN EMS_MachineMasterlist AS mml ON tln.fldMachineID = mml.fldMachineID
            WHERE tln.fldDate LIKE '20%'
            AND mml.fldDivision = ?
            AND mml.fldSection = ?
            AND mml.fldMachineID = ?
            AND (mml.fldStatus = ? OR mml.fldStatus = ? OR mml.fldStatus = ?)
        )
        SELECT *
        FROM MachineData
        WHERE rn = 1 ORDER BY fldID DESC
        '''
            dbEMS.Module.parameter = ()
            parameter =  list(dbEMS.Module.parameter)
            parameter.append(MachineInfo.division)
            parameter.append(MachineInfo.section)
            parameter.append(MachineInfo.machineId)
            parameter.append("Down")
            parameter.append("Monitoring")
            parameter.append("For Repair")
            dbEMS.Module.parameter = tuple(parameter)

            dbEMS.Module.opencommand()
            dataRead = dbEMS.Module.exeReader()

            if dataRead:
                for row in dataRead:

                    global down
                    dt = row.fldActualStart
                    yr = int(dt.strftime('%Y'))
                    month = int(dt.strftime('%m'))
                    day = int(dt.strftime('%d'))
                    hr =  int(dt.strftime('%H'))
                    mnt = int(dt.strftime('%M'))
                    secs= int(dt.strftime('%S'))


                    down = datetime(yr, month, day, hr, mnt, secs)
                    counter = datetime.now() - down

                    days = counter.days
                    hours, remainder = divmod(counter.seconds, 3600)
                    minutes, seconds = divmod(remainder, 60)

                    result = f"{days:02d}:{hours:02d}:{minutes:02d}:{seconds:02d}"



                    if row.fldStatus == 'Down':
                        lgnd = '#D04848' # Red
                    elif row.fldStatus == 'Monitoring':
                        lgnd = '#0F2C67' # Blue
                    elif row.fldStatus == 'For Repair':
                        lgnd = '#F3950D' #Yellow
                    else:
                        lgnd = '#36AE7C'


                    machineFrame = Frame(dataFrame, highlightbackground="Gray", highlightthickness=1, height=200)
                    machineFrame.pack(side=TOP, fill=X, expand=False, pady=5)

                    legend = Label(machineFrame, text='', bg= lgnd, width = 1, justify= LEFT, anchor=CENTER)
                    legend.grid(row=0, column=0, rowspan=3, sticky=NSEW)

                    machine = Label(machineFrame, text=f'{row.fldMachineID} - ({row.fldMachineName})', font=("Bahnschrift", 16, BOLD), fg="Black", width = 60, justify= LEFT, anchor=W)
                    machine.grid(row=0, column=1, sticky=W)

                    downTime = Label(machineFrame, text=row.fldActualStart.strftime("%m/%d/%Y, %I:%M:%S %p"), font=("Bahnschrift", 14), fg="Black", width = 20, justify=RIGHT, anchor=E)
                    downTime.grid(row=0, column=1, columnspan= 2, sticky=E)

                    line = Canvas(machineFrame, height=2, bg = "Gray", width = 720)
                    line.grid(row=1, column=1, columnspan=2, sticky=NW)

                    # Column 1:
                    detailsFrame = Frame(machineFrame)
                    detailsFrame.grid(row=2, column= 1, sticky=NSEW)

                    divSec = Label(detailsFrame, text=row.fldDivision, font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT, width = 25)
                    divSec.grid(row=0, column=0,  sticky=W)

                    status = Label(detailsFrame, text=row.fldStatus, font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT, width = 25)
                    status.grid(row=1, column=0,  sticky=W)

                    registrar = Label(detailsFrame, text=row.fldPE, font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT, width = 25)
                    registrar.grid(row=2, column=0,  sticky=W)

                    # Column 2:
                    troubleType = Label(detailsFrame, text=row.fldTroubleType, font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT, width = 50)
                    troubleType.grid(row=0, column=1,  sticky=W)

                    lbldownDetatils = Label(detailsFrame, text='Down Description:', font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT, width = 20)
                    lbldownDetatils.grid(row=1, column=1,  sticky=W)

                    downDetatils = Label(detailsFrame, text=row.fldDetails, font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT, width=50)
                    downDetatils.grid(row=2, column=1,  sticky=W)

                    # Column 3:
                    global downTimer
                    downTimer = Label(detailsFrame, text=result, font=("Bahnschrift", 25, BOLD), fg="Maroon", anchor = E, justify=RIGHT, width = 10)
                    downTimer.grid(row=0, column=2, rowspan=3, sticky=E)
            dbEMS.Module.closeqry()
       
        def Update_Timer():
            # Calculate elapsed time
            for widget in dataFrame.winfo_children():
                widget.destroy()

            Machine_Status()

            # Schedule this function to run again after 1000ms (1 second)
            dataFrame.after(1000, Update_Timer)
        #endregion

        Down_Counter()
        Machine_Status()
        Update_Timer()

        btnDowntimeFrame = Frame(self)
        btnDowntimeFrame.pack(side = BOTTOM, fill = X, expand= False)

        btnCreateReport = Button(btnDowntimeFrame, text = "Create Report", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command=self.Create_Report)
        btnCreateReport.pack(side = LEFT, padx=10, pady=10)

        btnMachineHistory = Button(btnDowntimeFrame, text = "Downtime History", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command=Downtime.Downtime_History)
        btnMachineHistory.pack(side = LEFT, padx=10, pady= 10)

    def Downtime_History():
        #region -- Downtime History --

        for frame in downtimeFrame.winfo_children():
            frame.destroy()

        header = Frame(downtimeFrame, bg = 'SteelBlue')
        header.pack(side = TOP, fill = BOTH, expand= False)

        historyCanvas = Canvas(downtimeFrame)
        historyCanvas.pack(side = LEFT, fill= BOTH, expand=TRUE)
        historyCanvas.pack_propagate(False)
        historyCanvas.configure(width = 700, height = 450)


        scrollbar = Scrollbar(downtimeFrame, orient=VERTICAL, command=historyCanvas.yview)
        historyFrame = Frame(historyCanvas)

        historyFrame.bind(
            "<Configure>",
            lambda e: historyCanvas.configure(
                scrollregion=historyCanvas.bbox("all")
            )
        )

        historyCanvas.create_window((0, 0), window=historyFrame, anchor=NW)

        historyCanvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side=RIGHT, fill=Y)

        def Machine_Count():
            dbEMS.Module.openquery()
            dbEMS.Module.query = '''
        WITH MachineData AS (
            SELECT
                tln.fldMachineID,
                mml.fldMachineName,
                mml.fldDivision,
                mml.fldSection,
                tln.fldStatus,
                tln.fldPE,
                tln.fldControlNumber,
                tln.fldDetails,
                tln.fldTroubleType,
                tln.fldInterval,
                tln.fldDate,
                tln.fldActualStart,
                tln.fldID,
                ROW_NUMBER() OVER(PARTITION BY mml.fldMachineID ORDER BY tln.fldDate DESC) AS rn
            FROM EMS_TroubleLogNew AS tln
            FULL OUTER JOIN EMS_MachineMasterlist AS mml ON tln.fldMachineID = mml.fldMachineID
            WHERE tln.fldDate LIKE '20%'
            AND tln.fldMachineID = ?
            AND mml.fldDivision = ?
            AND mml.fldSection = ?
            AND (mml.fldStatus = ? OR mml.fldStatus = ? OR mml.fldStatus = ? OR mml.fldStatus = ?)
        )
        SELECT *
        FROM
        (SELECT COUNT (fldMachineName) AS Machine FROM MachineData ) a,
        (SELECT COUNT (fldStatus) AS Down FROM MachineData WHERE fldStatus = ?) b,
        (SELECT COUNT (fldStatus) AS Monitoring FROM MachineData WHERE fldStatus = ? ) c,
        (SELECT COUNT (fldStatus) AS ForRepair FROM MachineData WHERE fldStatus = ?) d,
        (SELECT COUNT (fldStatus) AS Operational FROM MachineData WHERE fldStatus = ?) e
            '''

            dbEMS.Module.parameter = ()
            parameter = list(dbEMS.Module.parameter)
            parameter.append(MachineInfo.machineId)
            parameter.append(MachineInfo.division)
            parameter.append(MachineInfo.section)
            parameter.append("Down")
            parameter.append("Monitoring")
            parameter.append("For Repair")
            parameter.append("Operational")
            parameter.append("Down")
            parameter.append("Monitoring")
            parameter.append("For Repair")
            parameter.append("Operational")
            dbEMS.Module.parameter = tuple(parameter)

            dbEMS.Module.opencommand()
            downReader = dbEMS.Module.exeReader()
            if downReader:
                for row in downReader:
                    downFrame = Frame(header, bg = 'SteelBlue')
                    downFrame.pack(side = TOP, fill = Y, expand = False)

                    AllMachine = Label(downFrame, text=f'All Machine: {row.Machine}', justify= CENTER, anchor=CENTER, font=("Bahnschrift", 12, BOLD), height=2 , bg = 'SteelBlue', fg = 'White')
                    AllMachine.grid(row=0, column=0, sticky=NSEW, padx=(0, 20))

                    line1 = Label(downFrame, text=f'', justify= CENTER, anchor=CENTER, bg = '#D04848', width=2)
                    line1.grid(row=0, column=1)

                    down = Label(downFrame, text=f'Down: {row.Down}', justify= CENTER, font=("Bahnschrift", 12, BOLD), anchor=CENTER, bg = 'SteelBlue', fg = 'White')
                    down.grid(row=0, column=2, sticky=NSEW, padx=(0, 15))

                    line2 = Label(downFrame, text=f'', justify= CENTER, anchor=CENTER, bg = '#0F2C67', width=2)
                    line2.grid(row=0, column=3)

                    monitoring = Label(downFrame, text=f'Monitoring: {row.Monitoring}', font=("Bahnschrift", 12, BOLD), justify= CENTER, anchor=CENTER, bg = 'SteelBlue', fg = 'White')
                    monitoring.grid(row=0, column=4, sticky=NSEW, padx=(0, 15))

                    line3 = Label(downFrame, text=f'', justify= CENTER, anchor=CENTER, bg = '#F3950D', width=2)
                    line3.grid(row=0, column=5)

                    repair = Label(downFrame, text=f'For Repair: {row.ForRepair}', font=("Bahnschrift", 12, BOLD), justify= CENTER, anchor=CENTER, bg = 'SteelBlue', fg = 'White')
                    repair.grid(row=0, column=6, sticky=NSEW, padx=(0, 15))

                    line4 = Label(downFrame, text=f'', justify= CENTER, anchor=CENTER, bg = '#36AE7C', width=2)
                    line4.grid(row=0, column=7)

                    operational = Label(downFrame, text=f'Operational: {row.Operational}', font=("Bahnschrift", 12, BOLD), justify= CENTER, anchor=CENTER, bg = 'SteelBlue', fg = 'White')
                    operational.grid(row=0, column=8, sticky=NSEW, padx=(0, 15))
            dbEMS.Module.closeqry()

        def Down_History():
            dbEMS.Module.openquery()
            dbEMS.Module.query = '''
            WITH MachineData AS (
            SELECT
                tln.fldMachineID,
                mml.fldMachineName,
                mml.fldDivision,
                mml.fldSection,
                tln.fldStatus,
                tln.fldPE,
                tln.fldControlNumber,
                tln.fldDetails,
                tln.fldTroubleType,
                tln.fldInterval,
                tln.fldDate,
                tln.fldActualStart,
                tln.fldActualEnd,
                tln.fldID,
                ROW_NUMBER() OVER(PARTITION BY mml.fldMachineID ORDER BY tln.fldDate DESC) AS rn
            FROM EMS_TroubleLogNew AS tln
            FULL OUTER JOIN EMS_MachineMasterlist AS mml ON tln.fldMachineID = mml.fldMachineID
            WHERE tln.fldDate LIKE '20%'
            AND tln.fldMachineID = ?
            AND mml.fldDivision = ?
            AND mml.fldSection = ?
            AND (mml.fldStatus = ? OR mml.fldStatus = ? OR mml.fldStatus = ? OR  mml.fldStatus = ?)
        )
        SELECT *
        FROM MachineData
        ORDER BY fldID DESC
            '''

            dbEMS.Module.parameter = ()
            parameter = list(dbEMS.Module.parameter)
            parameter.append(MachineInfo.machineId)
            parameter.append(MachineInfo.division)
            parameter.append(MachineInfo.section)
            parameter.append("Down")
            parameter.append("Monitoring")
            parameter.append("For Repair")
            parameter.append("Operational")
            dbEMS.Module.parameter = tuple(parameter)
            
            dbEMS.Module.opencommand()
            dataRead = dbEMS.Module.exeReader()

            if dataRead:
                for row in dataRead:
                    fixedDate = "--/--/--, --:--:-- --"

                    if row.fldStatus == 'Down':
                        lgndClr = '#D04848' # Red
                    elif row.fldStatus == 'Monitoring':
                        lgndClr = '#0F2C67' # Blue
                    elif row.fldStatus == 'For Repair':
                        lgndClr = '#F3950D' #Yellow
                    elif row.fldStatus == 'Operational':
                        lgndClr = '#36AE7C'
                        fixedDate = row.fldActualEnd.strftime("%m/%d/%Y, %I:%M:%S %p")


                    containerFrame = Frame(historyFrame, highlightbackground='Gray', highlightthickness=1, height=200, width = 400)
                    containerFrame.pack(side = TOP, fill=X, expand=False, pady=5)

                    legend = Label(containerFrame, text='', bg= lgndClr, width = 1, justify= LEFT, anchor=CENTER)
                    legend.grid(row=0, column=0, rowspan=3, sticky=NSEW)

                    machine = Label(containerFrame, text=f'{row.fldMachineID} - ({row.fldMachineName})', font=("Bahnschrift", 14, BOLD), justify= LEFT, anchor=W, width=63)
                    machine.grid(row=0, column=1, sticky=W)

                    line = Canvas(containerFrame, height=2, bg = "Gray", width = 700)
                    line.grid(row=1, column=1, sticky=NW)

                    detailsFrame = Frame(containerFrame)
                    detailsFrame.grid(row=2, column= 1, sticky=NSEW)

                    label1 = Label(detailsFrame, text='Date Down:', font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT)
                    label1.grid(row=0, column=0,  sticky=NW)

                    label2 = Label(detailsFrame, text='Date End:', font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT)
                    label2.grid(row=1, column=0,  sticky=NW)

                    label3 = Label(detailsFrame, text='Reported By:', font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT)
                    label3.grid(row=0, column=2,  sticky=NW)

                    label4 = Label(detailsFrame, text='Details:', font=("Bahnschrift", 10), fg="Black", anchor = W, justify=LEFT)
                    label4.grid(row=1, column=2,  sticky=NW)

                    downTime = Label(detailsFrame, text=row.fldActualStart.strftime("%m/%d/%Y, %I:%M:%S %p"), font=("Bahnschrift", 10), fg="Black", justify=LEFT, anchor=W, width = 40)
                    downTime.grid(row=0, column=1,  sticky=NW)

                    fixedDate = Label(detailsFrame, text=fixedDate, font=("Bahnschrift", 10), fg="Black", justify=LEFT, anchor=W)
                    fixedDate.grid(row=1, column=1,  sticky=NW)

                    reportedBy = Label(detailsFrame, text=row.fldPE, font=("Bahnschrift", 10), fg="Black", justify=LEFT, anchor=W)
                    reportedBy.grid(row=0, column=3,  sticky=NW)

                    details = Label(detailsFrame, text=row.fldDetails, font=("Bahnschrift", 10), fg="Black",  justify=LEFT, anchor=W, width = 37, wraplength=280)
                    details.grid(row=1, column=3,  sticky=NW)
        
        #endregion

        Machine_Count()
        Down_History()

    def Create_Report(self):
        #region -- Submit Report --
        global report_window, report_notebook, report_frame, cause_frame, status_frame
        report_window=Toplevel(self.root)
        report_window.geometry("874x450")
        report_window.title("Submit Downtime Report")
        report_window.resizable(0,0)

        reportFrame = Frame(report_window, bg = "pink")
        reportFrame.pack( fill = BOTH, expand=True)

        report_notebook = ttk.Notebook(reportFrame)
        report_notebook.pack(fill = BOTH, expand=True)

        report_frame = Frame(report_notebook)
        cause_frame = Frame(report_notebook)
        status_frame = Frame(report_notebook)
        cancel_frame = Frame(report_notebook)

        report_frame.pack(fill=BOTH, expand=1)
        cause_frame.pack(fill=BOTH, expand=1)
        status_frame.pack(fill=BOTH, expand=1)
        cancel_frame.pack(fill=BOTH, expand=1)

        report_notebook.add(report_frame, text="Report")
        report_notebook.add(cause_frame, text="Cause")
        report_notebook.add(status_frame, text="Status")
        report_notebook.add(cancel_frame, text="Cancel")

        report_notebook.bind('<<NotebookTabChanged>>', Downtime.downtime_notebook_exit)
        #endregion
        
        Submit_Report_Tabs.Report_Tab()
        Submit_Report_Tabs.Cause_Tab()
        Submit_Report_Tabs.Status_Tab()

    def pick_date(event):
        global cal, date_window

        date_window = Toplevel()
        date_window.grab_set()
        date_window.title("Choose Date")
        date_window.geometry("250x220+590+370")
        date_window.resizable(0,0)

        cal = Calendar(date_window, selectmode ="day", date_pattern = "mm/dd/y")
        cal.pack()

        submit_btn = Button(date_window, text = "Submit", command=Downtime.grab_date)
        submit_btn.pack(fill=BOTH, expand=True)

    def grab_date():
        dtpDate.delete(0, END)
        dtpDate.insert(0, cal.get_date())
        date_window.destroy()

    def downtime_notebook_exit(*args):
        tab_index =  report_notebook.index(report_notebook.select())

        if tab_index == 3:
            #openRoot()
            report_window.destroy()


class Submit_Report_Tabs:
    def Report_Tab():
        #region -- Report Frame --
        lbl11 = Label(report_frame, text = "Downtime Report", font = ("Bahnschrift", 18, BOLD), justify = LEFT, fg="Black", anchor = "w")
        lbl11.place(x=0, y=0)

        lbl12 = Label(report_frame, text = "Reported To:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl12.grid(row = 1, column= 0, sticky=NW, padx=5, pady=(45,5))

        lbl13 = Label(report_frame, text = "Date:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl13.grid(row = 2, column= 0, sticky=NW, padx=5, pady=(0,5))

        lbl14 = Label(report_frame, text = "Prod InCharge:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl14.grid(row = 1, column= 2, sticky=NW, padx=5, pady=(45,5))

        lbl15 = Label(report_frame, text = "Trouble Type:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl15.grid(row = 2, column= 2, sticky=NW, padx=5, pady=(0,5))

        lbl16 = Label(report_frame, text = "Trouble Details:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl16.grid(row = 3, column= 0, sticky=NW, padx=5, pady=(0,5))


        global cmb_reportedTo, dtpDate, troubleDetails, prodInCharge, cmb_troubleType

        rprt = ('', 'Production Engineering', 'Quality Assurance', 'Production', 'Material Operation')
        rprtString = StringVar(value = rprt[0])
        cmb_reportedTo =  Combobox(report_frame, textvariable=rprtString,  width=20, background="White", font = ("Bahnschrift", 15))
        cmb_reportedTo['values'] = rprt

        global dtpDate
        #datetime picker
        dtpDate = Entry(report_frame, width = 22, background="White", font = ("Bahnschrift", 15), fg="#6B6A69", relief=FLAT)
        dtpDate.insert(0, "dd/mm/yyyy")
        dtpDate.bind("<1>", Downtime.pick_date)

        prodInCharge = Entry(report_frame, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)

        trblType = ('', 'N/A',)
        trblString = StringVar(value = rprt[0])
        cmb_troubleType =  Combobox(report_frame, textvariable=trblString,  width=20, background="White", font = ("Bahnschrift", 15))
        cmb_troubleType['values'] = trblType

        troubleDetails = Text(report_frame,height=3, width = 61, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)

        cmb_reportedTo.grid(row = 1, column= 1, sticky=NW, pady=(45,5), padx=(5, 30))
        dtpDate.grid(row=2, column=1, sticky=NW, padx=5, pady=(0,5))
        prodInCharge.grid(row=1, column=3, sticky=NW, padx=5, pady=(45,5))
        cmb_troubleType.grid(row=2, column=3, sticky=NW, padx=5, pady=(0,5))
        troubleDetails.grid(row=3, column=1, sticky=NW , padx=5, pady=(0,5), columnspan=3)

        # Defective Parts
        # region --- Defective Parts Labels --
        lbl17 = Label(report_frame, text = "Defective Parts", font = ("Bahnschrift", 18, BOLD), justify = LEFT, fg="Black", anchor = "w")
        lbl17.place(x = 0, y = 230)

        lbl18 = Label(report_frame, text = "Description:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl18.grid(row = 4, column= 0, sticky=NW, padx=5, pady=(75,5))

        lbl19 = Label(report_frame, text = "Maker:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl19.grid(row = 5, column= 0, sticky=NW, padx=5, pady=(0,5))

        lbl20 = Label(report_frame, text = "Model:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl20.grid(row = 6, column= 0, sticky=NW, padx=5, pady=(0,5))

        lbl21 = Label(report_frame, text = "Serial:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl21.grid(row = 4, column= 2, sticky=NW, padx=5, pady=(75,5))

        lbl22 = Label(report_frame, text = "Quantity:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl22.grid(row = 5, column= 2, sticky=NW, padx=5, pady=(0,5))
        # endregion

        global description, maker, model, serial, quantity
        description = Entry(report_frame, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        maker = Entry(report_frame, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        model = Entry(report_frame, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        serial = Entry(report_frame, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        quantity = Entry(report_frame, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)


        description.configure(state="disabled", disabledbackground="#cccccc")
        maker.config(state="disabled", disabledbackground="#cccccc")
        model.config(state="disabled", disabledbackground="#cccccc")
        serial.config(state="disabled", disabledbackground="#cccccc")
        quantity.config(state="disabled", disabledbackground="#cccccc")


        description.grid(row = 4, column= 1, sticky=NW, padx= 5, pady=(75,5))
        maker.grid(row=5, column=1, sticky=NW, padx=5, pady=(0,5))
        model.grid(row=6, column=1, sticky=NW, padx=5, pady=(0,5))
        serial.grid(row=4, column=3, sticky=NW, padx=5, pady=(75,5))
        quantity.grid(row=5, column=3, sticky=NW, padx=5, pady=(0,5))
        #endregion

    def Cause_Tab():
        #region -- Cause Frame --
        global investigation, rootCause, actionTaken

        lbl23 = Label(cause_frame, text = "Investigation:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl23.pack(side=TOP, fill=X, padx=10, pady=(15, 0))

        investigation = Text(cause_frame,height=3, width = 70, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        investigation.pack(side=TOP, fill=X, padx=10, pady=(0, 15))

        lbl24 = Label(cause_frame, text = "Root Cause:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl24.pack(side=TOP, fill=X, padx=10)

        rootCause = Text(cause_frame,height=3, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        rootCause.pack(side=TOP, fill=X, padx=10, pady=(0, 15))

        lbl25 = Label(cause_frame, text = "Action Taken:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl25.pack(side=TOP, fill=X, padx=10)

        actionTaken = Text(cause_frame,height=3, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        actionTaken.pack(side=TOP, fill=X, padx=10, pady=(0, 15))

        #endregion -- END - Cause Frame --

    def Status_Tab():
        #region -- Status Frame --
        global recomendation, remarks, rb_down, rb_operational, rb_forRepair, rb_monitoring, status_var
        lbl26 = Label(status_frame, text = "Recomendation:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl26.pack(side=TOP, fill=X, padx=10, pady=(15, 0))

        recomendation = Text(status_frame,height=3, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        recomendation.pack(side=TOP, fill=X, padx=10, pady=(0, 15))

        lbl27 = Label(status_frame, text = "Remarks:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl27.pack(side=TOP, fill=X, padx=10, pady=(15, 0))

        remarks= Text(status_frame,height=3, width = 22, background="White", font = ("Bahnschrift", 15), fg="Black", relief=FLAT)
        remarks.pack(side=TOP, fill=X, padx=10, pady=(0, 15))

        # Machine Status
        line = Canvas(status_frame, width = 700, height = 1, bg = "Gray")
        line.pack(side=TOP, fill=X)

        lbl28 = Label(status_frame, text = "Machine Status:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lbl28.pack(side=TOP, fill=X, padx=10, pady=(15, 0))

        radioButtonFrame = Frame(status_frame)
        radioButtonFrame.pack(side=TOP, fill=X, padx=10, pady=(0, 15))

        status_var = IntVar(radioButtonFrame)
        rb_operational = Radiobutton(radioButtonFrame, text="Operational", variable=status_var, value=1, font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w", command=Submit_Report_Tabs.RB_Results)
        rb_operational.grid(row=1, column=1, padx= (120,15))

        rb_down = Radiobutton(radioButtonFrame, text="Down", variable=status_var, value=2, font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w", command=Submit_Report_Tabs.RB_Results)
        rb_down.grid(row=1, column=2, padx= 15)

        rb_forRepair = Radiobutton(radioButtonFrame, text="For Repair", variable=status_var, value=3, font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w", command=Submit_Report_Tabs.RB_Results)
        rb_forRepair.grid(row=1, column=3, padx= 15)

        rb_monitoring = Radiobutton(radioButtonFrame, text="Monitoring", variable=status_var, value=4, font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w", command=Submit_Report_Tabs.RB_Results)
        rb_monitoring.grid(row=1, column=4, padx= 15)

        btn_submit = Button(status_frame, text = "SUBMIT", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, justify=CENTER, command=Submit_Report_Tabs.Submit_Report)
        btn_submit.pack(side=TOP, fill=X, padx=10)

        #endregion -- END - Status Frame --
    
    def RB_Results():
            global machineStatus
            machineStatus = int(status_var.get())


    def Submit_Report():

        # Report Tab Variables
        sub_reportedTo = cmb_reportedTo.get()
        sub_date = dtpDate.get()
        sub_troubleDetails = troubleDetails.get("1.0","end-1c")
        sub_inCharge = prodInCharge.get()
        sub_troubleType = cmb_troubleType.get()

        # Defective Parts Variables
        sub_description = description.get()
        sub_maker = maker.get()
        sub_model = model.get()
        sub_serial = serial.get()
        sub_quantity = quantity.get()

        # Cause Tab Variables
        sub_investigation = investigation.get("1.0","end-1c")
        sub_rootCause = rootCause.get("1.0","end-1c")
        sub_actionTaken = actionTaken.get("1.0","end-1c")

        # Status Tab and Submit Variables
        sub_recomendation = recomendation.get("1.0","end-1c")
        sub_remarks = remarks.get("1.0","end-1c")
        sub_status = ""
        sub_show = 0

        # rb_down
        # rb_operational
        # rb_forRepair
        # rb_monitoring

        if (machineStatus == 1):
            sub_status = rb_operational.cget("text")
            sub_show = 0
        elif (machineStatus == 2):
            sub_status = rb_down.cget("text")
            sub_show = 1
        elif (machineStatus == 3):
            sub_status = rb_forRepair.cget("text")
            sub_show = 1
        elif (machineStatus == 4):
            sub_status = rb_monitoring.cget("text")
            sub_show = 1
        else:
            sub_status = "Error"
            sub_show = 0

        

        dt = datetime.now()

        Submit_Report_Tabs.EMS_Trouble_Log_Control_Number()

        #region -- UPDATE STATUS (EMS_MachineMasterlist) --
        dbEMS.Module.openquery()
        dbEMS.Module.query = "UPDATE EMS_MachineMasterlist SET fldStatus = ? WHERE fldMachineID = ?"
        dbEMS.Module.parameter = ()
        parameter = list(dbEMS.Module.parameter)
        parameter.append(sub_status)
        parameter.append(MachineInfo.machineId)
        dbEMS.Module.parameter = tuple(parameter)

        dbEMS.Module.opencommand()
        dbEMS.Module.conn.commit()
        dbEMS.Module.closeqry()
        #endregion

        
        #region -- SUBMIT Trouble Reporter (Trouble Reporter) --
        dbEMS.Module.openquery()
        dbEMS.Module.query = '''
            INSERT INTO EMS_TroubleReporter 
            (fldReporter, fldMachineID, fldControlNumber, fldStatus, fldDate)
            VALUES
            (?,?,?,?,?)
            '''
        dbEMS.Module.parameter = ()
        parameter = list(dbEMS.Module.parameter)
        parameter.append(sub_inCharge)
        parameter.append(MachineInfo.machineId)
        parameter.append(tlnGeneratedControlNo)
        parameter.append(sub_status)
        parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
        dbEMS.Module.parameter = tuple(parameter)

        dbEMS.Module.opencommand()
        dbEMS.Module.conn.commit()
        dbEMS.Module.closeqry()
        #endregion

        #region -- UPDATE Trouble Log New - Show (EMS_Truble Log New) --
        if sub_status == "Operational":
            dbEMS.Module.openquery()
            dbEMS.Module.query = '''
                    SELECT  *  FROM EMS_TroubleLogNew 
                    WHERE fldMachineID = ?
                    AND fldStatus <> ? ORDER BY fldID DESC
            '''
            dbEMS.Module.parameter = ()
            parameter = list(dbEMS.Module.parameter)
            parameter.append(MachineInfo.machineId)
            parameter.append("Operational")
            dbEMS.Module.parameter = tuple(parameter)

            dbEMS.Module.opencommand()

            readDB = dbEMS.Module.exeReader()
            if readDB:
                for rows in readDB:
                    dtControlNo = rows.fldControlNumber

                    #for Time Interval
                    start_str = rows.fldActualStart

                    #startTime = datetime.strptime(start_str , f"%Y-%m-%d %H:%M:%S")
                    endTIme = datetime.now()

                    interval_cal = endTIme - start_str
                    interval = interval_cal.total_seconds()

                    dbEMS.Module.openquery()
                    dbEMS.Module.query = '''
                        UPDATE EMS_TroubleLogNew 
                        SET fldStatus = ?, fldShow = ? , fldComplete = ?, fldActualEnd = ?, fldInterval = ?, fldAttendedBy = ?, fldRespondent = ?
                        WHERE fldControlNumber = ? 
                    '''
                    dbEMS.Module.parameter = ()
                    parameter = list(dbEMS.Module.parameter)
                    parameter.append("Operational")
                    parameter.append(0)
                    parameter.append(1)
                    parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
                    parameter.append(interval)
                    parameter.append(sub_inCharge)
                    parameter.append(sub_inCharge)
                    parameter.append(dtControlNo)
                    

                    dbEMS.Module.parameter = tuple(parameter)

                    dbEMS.Module.opencommand()
                    dbEMS.Module.conn.commit()
            
            dbEMS.Module.closeqry()

        else:
            #region -- SUBMIT Trouble Report (Trouble Log New) --
            dbEMS.Module.openquery()
            dbEMS.Module.query = '''
                INSERT INTO EMS_TroubleLogNew 
                (fldControlNumber, fldMachineID, fldDate, fldActualStart, fldPE, fldDetails, fldInvestigation, fldRootCause, fldActionTaken, fldDisposition, fldStatus, fldRegistrar, fldCorrection, fldShow, fldTroubleType, fldRemarks, fldReportedTo, fldComplete)
                VALUES
                (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    '''
            dbEMS.Module.parameter = ()
            parameter = list(dbEMS.Module.parameter)
            parameter.append(tlnGeneratedControlNo)
            parameter.append(MachineInfo.machineId)
            parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
            parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
            parameter.append(sub_inCharge)
            parameter.append(sub_troubleDetails)
            parameter.append(sub_investigation)
            parameter.append(sub_rootCause)
            parameter.append(sub_actionTaken)
            parameter.append(sub_recomendation)
            parameter.append(sub_status)
            parameter.append(sub_inCharge)
            parameter.append("Production Engineering")
            parameter.append(sub_show)
            parameter.append(sub_troubleType)
            parameter.append(sub_remarks)
            parameter.append(sub_reportedTo)
            parameter.append(0)
            dbEMS.Module.parameter = tuple(parameter)

            dbEMS.Module.opencommand()
            dbEMS.Module.conn.commit()
            dbEMS.Module.closeqry()

            #endregion

    #endregion -- UPDATE Trouble Log New - Show (EMS_Truble Log New) --


    def EMS_Trouble_Log_Control_Number():
        global tln, tlnCnt, tlnGeneratedControlNo

        dt = datetime.now()
        tln = f"DT-{dt.strftime(f'%y%m%d')}"

        dbEMS.Module.query = "SELECT COUNT (fldID) AS mano FROM EMS_TroubleLogNew WHERE fldControlNumber LIKE ?"
        dbEMS.Module.parameter = f'%{tln}%'
        dbEMS.Module.openquery()
        dbEMS.Module.opencommand()
        readDB = dbEMS.Module.exeReader()
        if readDB:
            for rows in readDB:
                tlnCnt = int(rows.mano) + 1
            tlnGeneratedControlNo = f"{tln}-{tlnCnt:03}"
        dbEMS.Module.closeqry()
        return tlnGeneratedControlNo

    
    


def Run_DowntimePage(master, switch_frame, root):
    app = Downtime(master, switch_frame, root)
    app.pack()
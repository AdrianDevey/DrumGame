from datetime import datetime
from email import message
from tkinter import *
from tkinter import messagebox
from tkinter.font import BOLD
from tkinter.ttk import Combobox

from Database import module_v2 as db

#from Tools import timerV3 as Oras


class RunApp(Frame):
    def __init__(self, master, switch_frame):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame
        self.running = False

        # self.label = Label(self, text="This is the second tkinter file!")
        # self.label.pack(pady=20)

        # self.close_button = Button(self, text="Close", command=self.close_second_app)
        # self.close_button.pack(pady=10)Z
        RunApp.RunPage(self)
        

    def RunPage(self):
        frameRun = Frame(self)

        # Page Title
        lblRun = Label(frameRun, text = "Run ", font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblRun.pack(side = TOP, fill= BOTH)


        ### -- Run Page Labels -- #########################################################################################################
        lblProgramNo = Label(frameRun, text = "Program No.: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblModelNo = Label(frameRun, text = "Model No.: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblModelType = Label(frameRun, text = "Model Type: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblShopOrder = Label(frameRun, text = "Shop Order: ", font = ("Bahnschrift", 15),  justify = LEFT, fg="Black", anchor = "w")
        lblProdQty = Label(frameRun, text = "Prod. Qty: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblCycleTime = Label(frameRun, text = "Cycle Time: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblStatus = Label(frameRun, text = "Status: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        #lblStartTime = Label(frameRun, text = "Start Time: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        

        lblProgramNo.pack()
        lblModelNo.pack()
        lblModelType.pack()
        lblShopOrder.pack()
        lblStatus.pack()
        lblProdQty.pack()
        lblCycleTime.pack()
        lblStatus.pack()
        #lblStartTime.pack()
        

        lblProgramNo.place(x= 25, y = 50)
        lblModelNo.place(x = 25, y = 90)
        lblModelType.place(x = 25, y = 130)
        lblShopOrder.place(x = 25, y = 170)
        lblProdQty.place(x = 25, y = 210)
        lblCycleTime.place(x = 25, y = 250)
        lblStatus.place(x = 25, y = 410)
        #lblStartTime.place(x = 25, y =330)


        global lbl_Timer
        lbl_Timer = Label(frameRun, text="00:00",fg='Maroon', font = ("Bahnschrift", 60, BOLD), width=7, justify=CENTER, anchor=CENTER)
        lbl_Timer.place(x=400, y=100)
        # Oras = Meter(frameRun, padding=0)
        # Oras.pack(side = LEFT, expand=True, fill= BOTH)
        # Oras.place(x = 450, y = 50)

        actualQtyFrame = Frame(frameRun)
        actualQtyFrame.pack(side=LEFT)
        actualQtyFrame.pack_propagate(False)
        actualQtyFrame.configure(height=25, width=106)
        actualQtyFrame.place(x = 200, y = 370)

        targetQtyFrame = Frame(frameRun)
        targetQtyFrame.pack(side=LEFT)
        targetQtyFrame.pack_propagate(False)
        targetQtyFrame.configure(height=75, width=170)
        targetQtyFrame.place(x = 370, y = 255)
        
        productQtyFrame = Frame(frameRun)
        productQtyFrame.pack(side=LEFT)
        productQtyFrame.pack_propagate(False)
        productQtyFrame.configure(height=75, width=170)
        productQtyFrame.place(x = 570, y = 255)

        lblTargetQty = Label(frameRun, text = "Target Qty ", font = ("Bahnschrift", 15),  justify = LEFT, fg="Black", anchor = "w")
        lblActualQty = Label(frameRun, text = "End Quantity: ", font = ("Bahnschrift", 15),  justify = LEFT, fg="Black", anchor = "w")
        lblProductQty = Label(frameRun, text = "Product Qty: ", font = ("Bahnschrift", 15),  justify = LEFT, fg="Black", anchor = "w")


        lblTargetQty.pack()
        lblActualQty.pack()
        lblProductQty.pack()
        

        lblTargetQty.place(x = 400 , y = 325)
        lblActualQty.place(x = 25 , y = 370)
        lblProductQty.place(x = 596 , y = 325)
        


        ### -- Run Page Textboxes -- #########################################################################################################
        # txtModel =  Text(frameRun, height= 1, width = 40, background="White", font = ("Bahnschrift", 18), fg="Black")
        # txtShopOrder =  Text(frameRun, height= 1, width = 40, background="White", font = ("Bahnschrift", 18), fg="Black")
        # txtProdQty =  Text(frameRun, height= 1, width = 40, background="White", font = ("Bahnschrift", 18), fg="Black")
        # #txtActual =  Text(frameRun, height= 1, width = 40, background="White", font = ("Bahnschrift", 18), fg="Black")
        # #txtCompletionRate =  Text(frameRun, height= 1, width = 40, background="White", font = ("Bahnschrift", 18), fg="Black")


        # txtModel.pack()
        # txtShopOrder.pack()
        # txtProdQty.pack()
        # # txtActual.pack()
        # # txtCompletionRate.pack()

        # txtModel.place(x = 200, y = 75)
        # txtShopOrder.place(x = 200, y = 125)
        # txtProdQty.place(x = 200, y = 175)
        # # txtActual.place(x = 200, y = 225)
        # # txtCompletionRate.place(x = 200, y = 275)

        # canvas1 = Canvas(frameRun, width=325, height=175, bg="white")
        # canvas2 = Canvas(frameRun, width=325, height=175, bg="white")
        # canvas1.pack()
        # canvas2.pack()
        # canvas1.place(x = 25, y =275 )
        # canvas2.place(x = 395, y =275 )


        ### -- Run Page Variables -- #########################################################################################################
        global uniqueId, programNumber, modelNumber, modelType, shopOrder, productQty, cycleTime, status, targetQty, actualQty, startTime, prductlQty, txtStatus
        uniqueId = ""
        programNumber = Label(frameRun, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        modelNumber =  Label(frameRun, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        modelType = Label(frameRun, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        shopOrder =  Label(frameRun, text= '---',height= 1, font = ("Bahnschrift", 15), fg="Black")
        productQty =  Label(frameRun, text= '---',height= 1, font = ("Bahnschrift", 15), fg="Black")
        cycleTime =  Label(frameRun, text= '---',height= 1, font = ("Bahnschrift", 15), fg="Black")
        #status = Label(frameRun, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        startTime = Label(frameRun, text= '00:00:00 AA\n00/00/0000', height= 2, font = ("Bahnschrift", 15), fg="Black", justify=LEFT, anchor = "w",)
        targetQty = Label(targetQtyFrame, text= '0', font = ("Bahnschrift", 50), fg="Black")
        actualQty = Entry(actualQtyFrame, justify = LEFT, fg="Black", relief=FLAT, font = ("Bahnschrift", 15), width=15)
        prductlQty =  Label(productQtyFrame, text= '0', font = ("Bahnschrift", 50), fg="Black")

        programNumber.pack()
        modelNumber.pack()
        modelType.pack()
        shopOrder.pack()
        productQty.pack()
        cycleTime.pack()
        #status.pack()
        startTime.pack()
        actualQty.pack(side = LEFT, fill = X, expand=TRUE)
        targetQty.pack(side = LEFT, fill = BOTH, expand=TRUE)
        prductlQty.pack(side = LEFT, fill = BOTH, expand=TRUE)

        programNumber.place(x = 200, y = 50)
        modelNumber.place(x = 200, y = 90)
        modelType.place(x = 200, y = 130)
        shopOrder.place(x = 200, y = 170)
        productQty.place(x = 200, y = 210)
        cycleTime.place(x = 200, y = 250)
        #status.place(x = 200, y = 290)
        startTime.place(x = 625, y = 0)


        # ComboBox
        status = ('', 'Partial', 'Completed')
        statusString = StringVar(value = status[0])
        txtStatus =  Combobox(frameRun, textvariable=statusString, height= 1,  width=9, background="White", font = ("Bahnschrift", 12))
        txtStatus['values'] = status
        
        txtStatus.pack()

        txtStatus.place(x = 200, y = 410)

        


        ### -- Run Page Buttons -- #########################################################################################################
        btnFrame = Frame(frameRun, height=50)

        btnStop = Button(btnFrame, text = "Stop", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.stop_timer)
        btnStop.pack(padx=10)

        btnReset = Button(btnFrame, text = "Reset", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.reset_timer)
        btnReset.pack(padx=10)

        btnStart = Button(btnFrame, text = "Start", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.start_timer)
        btnStart.pack(padx=10)

        btnStop.place(x = 0, y = 0)
        btnReset.place(x = 275, y = 0)
        btnStart.place(x = 548, y = 0)

        btnFrame.pack(side = BOTTOM, expand=False, fill = BOTH)


        # timeFrame = Frame(frameRun, height=100, width=100)
        # Oras.run_Oras(timeFrame)
        # timeFrame.pack(expand=False, fill = BOTH)
        # timeFrame.place(x = 450, y = 50)


        frameRun.pack(side=LEFT, fill= BOTH, expand=1, padx = 10, pady = 10)
        frameRun.pack_propagate(False)
        frameRun.configure(height=600, width=1024)

    def countdown(self, count):
        lbl_Timer.config(text=f"{count // 60:02}:{count % 60:02}")

        if self.running:
            if count >= 0:
                # call countdown again after 1000ms (1s)
                if count == 0:
                    cnt_target = int(targetQty.cget("text")) + 1
                    targetQty.config(text=str(cnt_target))

                self.after(1000, self.countdown, count-1)
            else:
                self.countdown(cycleTime.cget("text"))


    def start_timer(self):
        if not self.running:
            if uniqueId != "":
                global actual_count
                self.running = True
                durationTime =  cycleTime.cget("text")
                self.countdown(durationTime)
                actual_count = 0
            else:
                messagebox.showerror("Item Not Found","Please set Production Data first!")

    def stop_timer(self):
        if uniqueId != "" and programNumber != "---":

            self.running = False

            msg = messagebox.askyesno("Save Data", "Please select yes to save data.")
            dt = datetime.now()
            if msg == 1:
                actual_qty = actualQty.get()
                status2 = txtStatus.get()

                if actual_qty.isdigit():
                    if status != "":
                        db.Module.openquery()
                        db.Module.query = "UPDATE RPI_Operation SET fldActualQty = ?, fldTarget = ?, fldTotalQty = ?, fldStatus = ?, fldStopTime = ? WHERE fldUniqueId = ?"
                        
                        db.Module.parameter = ()
                        parameter = list(db.Module.parameter)
                        parameter.append(actual_qty)
                        parameter.append(targetQty.cget("text"))
                        parameter.append(actual_qty)
                        parameter.append(status2)
                        parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
                        parameter.append(uniqueId)
                        db.Module.parameter = tuple(parameter)

                        db.Module.opencommand()
                        db.Module.conn.commit()
                        db.Module.closeqry()

                        #uniqueId = ""
                        programNumber.config(text = "---")
                        modelNumber.config(text = "---")
                        modelType.config(text = "---")
                        shopOrder.config(text = "---")
                        productQty.config(text = "---")
                        cycleTime.config(text = "---")
                        #status.config(text = "---")
                        startTime.config(text = "00:00:00 AA \n00/00/0000")
                        targetQty.config(text = 0)
                        lbl_Timer.config(text="00:00")


                else:
                    messagebox.showerror("Invalid Input", "Please enter numeric value only")

            else:
                self.running = True


    def reset_timer(self):
        msg = messagebox.askyesno("Reset Operation", "Are you sure you want to reset the operation?")
        if msg == 1:
            self.running = False
            
            programNumber.config(text = "---")
            modelNumber.config(text = "---")
            modelType.config(text = "---")
            shopOrder.config(text = "---")
            productQty.config(text = "---")
            cycleTime.config(text = "---")
            #status.config(text = "---")
            startTime.config(text = "00:00:00 AA \n00/00/0000")
            targetQty.config(text = 0)
            lbl_Timer.config(text="00:00")

    def close_second_app(self):
        # Hide this frame and switch back to the main frame
        self.pack_forget()
        self.switch_frame()


# Optional: Add a function to easily create and run the second app
def Run_RunPage(master, switch_frame):
    app = RunApp(master, switch_frame)
    app.pack()

    



from datetime import datetime
from tkinter import *
from tkinter import messagebox
from tkinter.font import BOLD
from tkinter.ttk import Combobox, Treeview


from Database import module_v2 as db
from Tools import MachineInfo


class DischargeApp(Frame):
    def __init__(self, master, switch_frame, root):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame
        self.root = root

        DischargeApp.Discharge(self)

    def Discharge(self):
        global frameDischarge
        frameDischarge = Frame(self)
        frameDischarge.pack(side=TOP, fill= BOTH, expand=1, padx = 10, pady = 10)
        frameDischarge.pack_propagate(False)
        frameDischarge.configure(height=500, width=1024)

        # Page Title
        lblDischargeTitle = Label(frameDischarge, text = "DC Fan Discharge Weight Monitoring", font = ("Bahnschrift", 20, BOLD), justify = LEFT, fg="Black", anchor = "w")
        lblDischargeTitle.pack(side = TOP, fill= BOTH)


        
        dt = datetime.now()
        # Tree View
        frameDischargeList = Frame(frameDischarge)

        treeviewItem = []

        db.Module.openquery()
        db.Module.query = "SELECT * FROM RPI_OilProof_DischargeWeight WHERE fldMachineId = ? AND fldDate LIKE ? ORDER BY fldRegisteredDate DESC"
        db.Module.parameter = ()
        parameter = list(db.Module.parameter)
        parameter.append(MachineInfo.machineId)
        parameter.append(f"%{dt.strftime(f'%y-%m-%d')}%")
        db.Module.parameter = tuple(parameter)
        db.Module.opencommand()
        reader = db.Module.exeReader()
        if reader:
            for row in reader:
                old_dt = datetime.strptime(row.fldDate, f'%Y-%m-%d')
                new_dt = old_dt.strftime(f'%y-%m-%d')

                time = row.fldTime
                oldTime = datetime.strptime(time, f'%H:%M:%S.%f')
                newTime = oldTime.strftime(f'%X')
                item = [
                    newTime,
                    new_dt,
                    row.fldShift,
                    row.fldPattern,
                    row.fldChemical,
                    row.fldActualDischargeWeight,
                    row.fldResult,
                    row.fldEmployeeName,
                    row.fldEmployeeCode,
                    row.fldRemarks
                ]
                treeviewItem.append(item)
        db.Module.closeqry()

        cols  = ('time', 'date', 'shift', 'pattern', 
            'chemical', 'actualDischarge', 'result', 'name',
            'code', 'remarks')
        
        text_dwm = ('Time', 'Date', 'Shift', 'Pattern',
            'Chemical', 'Actual Discharge Weight', 'Result',
            'Employee Name', 'Employee Code', 'Remarks')

        size = (60, 65, 60, 50, 90, 145, 50, 130, 100, 130)

        tv_dwm = Treeview(frameDischargeList, columns=cols, show='headings')

        dwm_cnt = 0
        for x in cols:
            tv_dwm.column(x, width=size[ dwm_cnt], anchor=CENTER)
            tv_dwm.heading(x, text=text_dwm[ dwm_cnt] )
            dwm_cnt += 1

        tv_dwm.tag_configure('ng', background='lightcoral')  # Example for high discharge weight
        tv_dwm.tag_configure('good', background='white')

        for dwmItem in treeviewItem:
            status = dwmItem[6]
            tag = 'good'

            if status == 'NG':
                tag = 'ng'
            tv_dwm.insert('', END, values=dwmItem, tags=(tag,))

        def Item_Selected(event):
            for selected_item in tv_dwm.selection():
                item = tv_dwm.item(selected_item)
                record = item['values']

        tv_dwm.bind('<<TreeviewSelect>>', Item_Selected)
        tv_dwm.pack(side=TOP, fill=BOTH, expand = True)


        xScroll = Scrollbar(frameDischargeList, orient=HORIZONTAL, command=tv_dwm.xview)
        tv_dwm.configure(xscrollcommand=xScroll.set)
        xScroll.pack(side=BOTTOM, fill = X)



        frameDischargeList.pack(side=TOP, fill= BOTH, expand = True)

        






        btnFrame = Frame(self)
        btnFrame.pack(side = TOP, fill = X, expand= False)

        btnSOC = Button(btnFrame, text = "Submit Entry", font = ("Bahnschrift", 18, BOLD), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command=self.Submit_Entry)
        btnSOC.pack(side = LEFT, padx=10, pady=10)

   
    def Submit_Entry(self):
        global submit_window
        submit_window = Toplevel(self.root)
        submit_window.geometry("400x420")
        submit_window.title("DC Fan Discharge Weight Monitoring")
        submit_window.resizable(0, 0)
        submit_window.attributes('-topmost', 'true')

        upperFrame = Frame(submit_window)
        upperFrame.pack(side=TOP, fill = X, expand= False)

        label = Label(upperFrame, text = f'DC Fan Discharge Weight Monitoring', font=("Bahnschrift", 12, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=0, sticky=NSEW, padx=(5, 0), pady=(5,0))

        label = Label(upperFrame, text = f'Machine Name: {MachineInfo.machineName}', font=("Bahnschrift", 12), justify= LEFT, anchor=W)
        label.grid(row=1, column=0, sticky=NSEW, padx=(5, 0))

        label = Label(upperFrame, text = f'Machine No.: {MachineInfo.machineNo}', font=("Bahnschrift", 12), justify= LEFT, anchor=W)
        label.grid(row=2, column=0, sticky=NSEW, padx=(5, 0))

        line = Canvas(upperFrame, height=1, bg = "Gray")
        line.grid(row=3, column=0, sticky=NSEW, padx= 10)


        bodyFrame = Frame(submit_window)
        bodyFrame.pack(side = TOP, fill=BOTH, expand=False)

        label = Label(bodyFrame, text=f'Shift:', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=0, column=0, sticky=NSEW, padx=15, pady=(15, 0))

        label = Label(bodyFrame, text=f'Pattern:', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=1, column=0, sticky=NSEW, padx=15, pady=(15, 0))

        label = Label(bodyFrame, text=f'Chemical:', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=2, column=0, sticky=NSEW, padx=15, pady=(15, 0))

        label = Label(bodyFrame, text=f'Actual Discharge:', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=3, column=0, sticky=NSEW, padx=15, pady=(15, 0))

        label = Label(bodyFrame, text=f'Employee Name:', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=4, column=0, sticky=NSEW, padx=15, pady=(15, 0))

        label = Label(bodyFrame, text=f'Employee Code:', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=5, column=0, sticky=NSEW, padx=15, pady=(15, 0))

        label = Label(bodyFrame, text=f'Remarks:', font=("Bahnschrift", 10, BOLD), justify= LEFT, anchor=W)
        label.grid(row=6, column=0, sticky=NSEW, padx=15, pady=(15, 0))

        #region -- Discharge Texboxed --

        # -- Cobobox --
        global cmb_shift, cmb_pattern, cmb_chemical
        global txt_discharge, txt_name, txt_code, txt_remarks
        # -- cmd shift --
        shft = StringVar()
        cmb_shift = Combobox(bodyFrame, width=24, textvariable=shft, font = ("Bahnschrift", 10))
        cmb_shift['values']  = ('Day Shift', 'Night Shift')
        cmb_shift.grid(row = 0, column= 1, sticky=NSEW, padx=(0, 15), pady=(15, 0))
        cmb_shift.current()

        # -- cmd pattern --
        pttrn = StringVar()
        cmb_pattern = Combobox(bodyFrame, width=24, textvariable=pttrn, font = ("Bahnschrift", 10))
        cmb_pattern['values']  = ()
        ls = list(cmb_pattern['values'])
        for i in range(1, 11):
            ls.append(i)
        cmb_pattern['values'] = tuple(ls)

        cmb_pattern.grid(row = 1, column= 1, sticky=NSEW, padx=(0, 15), pady=(15, 0))
        cmb_pattern.current()

        # -- cmd chemical --
        pttrn = StringVar()
        cmb_chemical = Combobox(bodyFrame, width=24, textvariable=pttrn, font = ("Bahnschrift", 10))
        cmb_chemical['values']  = ('Pelnox Epoxy', 'NAGASE Epoxy')
        
        cmb_chemical.grid(row = 2, column= 1, sticky=NSEW, padx=(0, 15), pady=(15, 0))
        cmb_chemical.current()


        txt_discharge =  Entry(bodyFrame, width = 26, font = ("Bahnschrift", 10), fg="Black")
        txt_discharge.grid(row=3, column=1, sticky=NSEW, padx=(0, 15), pady=(15, 0))

        txt_name =  Entry(bodyFrame, width = 26, font = ("Bahnschrift", 10), fg="Black")
        txt_name.grid(row=4, column=1, sticky=NSEW, padx=(0, 15), pady=(15, 0))

        txt_code =  Entry(bodyFrame, width = 26, font = ("Bahnschrift", 10), fg="Black")
        txt_code.grid(row=5, column=1, sticky=NSEW, padx=(0, 15), pady=(15, 0))

        txt_remarks =  Entry(bodyFrame, width = 26, font = ("Bahnschrift", 10), fg="Black")
        txt_remarks.grid(row=6, column=1, sticky=NSEW, padx=(0, 15), pady=(15, 0))
        #endregion


        btn_Frame = Frame(submit_window)
        btn_Frame.pack(side = BOTTOM, fill = X, expand= False)

        btnSubmit = Button(btn_Frame, text = "Submit", font = ("Bahnschrift", 10, "bold"), fg="white",  bg = "#1253a3",  bd = 0, justify=CENTER, command=self.Submit_Discharge)
        btnSubmit.pack(side = BOTTOM, fill=X, expand=True, padx=10, pady=10)

    def Submit_Discharge(self):
        try : 
            float(txt_discharge.get()) 
            is_float = True
        except : 
            #messagebox.showerror('Invalid Input', 'Actual Discharge Weight invalid input.')
            is_float = False
        
        try : 
            int(cmb_pattern.get()) 
            is_int = True
        except : 
            #messagebox.showerror('Invalid Input', 'Actual Discharge Weight invalid input.')
            is_int = False

        
        if is_float and is_int:

            dt = datetime.now()

            shift = cmb_shift.get()
            pattern = int(cmb_pattern.get())
            chemical = cmb_chemical.get()
            discharge = float(txt_discharge.get())
            name = txt_name.get()
            code = txt_code.get()
            remarks = txt_remarks.get()
            result = ""
            standard_discharge = ""


            if shift != "" and pattern != "" and chemical != "" and discharge != "" and name != "" and code != "" and remarks != "":
                    # Penox Epoxy Pattern Equivalent
                pelnox_epoxy = {
                    1: "1.29-1.69g",
                    2: "2.41-2.81g",
                    3: "8.89-9.59g",
                    4: "1.66-2.06g",
                    5: "3.01-3.51g",
                    6: "19.50-20.50g",
                    7: "3.90-4.40g",
                    8: "5.56-6.06g",
                    9: "12.60-13.40g",
                    10: "-"
                }

                # NAGASE Epoxy Pattern Equivalent
                nagase_epoxy = {
                    1: "1.60-2.00g",
                    2: "2.96-3.36g",
                    3: "10.83-11.53g",
                    4: "2.05-2.45g",
                    5: "3.69-4.19g",
                    6: "16.50-17.50g",
                    7: "4.77-5.27g",
                    8: "6.78-7.28g",
                    9: "15.32-16.12g",
                    10: "19.50-20.50"
                }

                if chemical == "Pelnox Epoxy":
                    match pattern:
                        case 1:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 1.29 and discharge <= 1.69:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 2:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 2.41 and discharge <= 2.81:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 3:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 8.89 and discharge <= 9.59:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 4:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 1.66 and discharge <= 2.06:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 5:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 3.01 and discharge <= 3.51:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 6:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 19.50 and discharge <= 20.50:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 7:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 3.90 and discharge <= 4.40:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 8:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 5.56 and discharge <= 6.05:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 9:
                            standard_discharge = pelnox_epoxy[pattern]
                            
                            if discharge >= 12.60 and discharge <= 13.40:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 10:
                            standard_discharge = pelnox_epoxy[pattern]
                            result = 'NG'

                        case _:
                            result = 'NG'

                elif chemical == "NAGASE Epoxy":
                    match pattern:
                        case 1:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 1.60 and discharge <= 2.00:
                                result = "Good"
                            else:
                                result = 'NG'
                        

                        case 2:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 2.96 and discharge <= 3.36:
                                result = "Good"
                            else:
                                result = 'NG'

                        
                        case 3:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 10.83 and discharge <= 11.53:
                                result = "Good"
                            else:
                                result = 'NG'

                        
                        case 4:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 2.05 and discharge <= 2.45:
                                result = "Good"
                            else:
                                result = 'NG'

                    
                        case 5:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 3.69 and discharge <= 4.19:
                                result = "Good"
                            else:
                                result = 'NG'

                            
                        case 6:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 16.50 and discharge <= 17.50:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 7:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 4.77 and discharge <= 5.27:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 8:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 6.78 and discharge <= 7.28:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 9:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 15.32 and discharge <= 16.12:
                                result = "Good"
                            else:
                                result = 'NG'


                        case 10:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 19.50 and discharge <= 20.50:
                                result = "Good"
                            else:
                                result = 'NG'


                        case _:
                            standard_discharge = nagase_epoxy[pattern]
                            
                            if discharge >= 1.29 and discharge <= 1.69:
                                result = "Good"
                            else:
                                result = 'NG'

            
                Generate_Unique_ID()
                db.Module.openquery()
                db.Module.query = '''
                    INSERT INTO RPI_OilProof_DischargeWeight 
                    (fldUniqueId, fldMachineId, fldMachineNo, fldDate,
                    fldShift, fldTime, fldPattern, fldChemical, fldActualDischargeWeight,
                    fldResult, fldStandardDischargeWeight, fldEmployeeName, 
                    fldEmployeeCode, fldRemarks, fldRegisteredDate) 
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'''
                db.Module.parameter = ()
                parameter = list(db.Module.parameter)
                parameter.append(dwmGeneratedControlNo)
                parameter.append(MachineInfo.machineId)
                parameter.append(MachineInfo.machineNo)
                parameter.append(dt.strftime(f'%Y-%m-%d'))
                parameter.append(shift)
                parameter.append(dt)
                parameter.append(pattern)
                parameter.append(chemical)
                parameter.append(discharge)
                parameter.append(result)
                parameter.append(standard_discharge)
                parameter.append(name)
                parameter.append(code)
                parameter.append(remarks)
                parameter.append(dt)
                db.Module.parameter = tuple(parameter)
                db.Module.opencommand()
                db.Module.conn.commit()
                db.Module.closeqry()

                submit_window.destroy()

                self.destroy()
                Run_dischargePage(self.master, self.switch_frame, self.root)
                
                

            else:
                submit_window.attributes('-topmost', 'false')
                messagebox.showerror("Missing Fields", "Please fill all required fields.")
                submit_window.attributes('-topmost', 'true')

        else:
            submit_window.attributes('-topmost', 'false')
            messagebox.showerror('Invalid Input', 'Invalid input. Please enter a valid input.')
            submit_window.attributes('-topmost', 'true')
            

def Generate_Unique_ID():
    global dwmGeneratedControlNo

    dt = datetime.now()
    dwm = f"DWM-{dt.strftime(f'%y%m%d')}"

    db.Module.query = "SELECT COUNT (fldId) AS mano FROM RPI_OilProof_DischargeWeight WHERE fldUniqueId LIKE ?"
    db.Module.parameter = f'%{dwm}%'
    db.Module.openquery()
    db.Module.opencommand()
    readDB = db.Module.exeReader()
    if readDB:
        for rows in readDB:
            dwmCnt = int(rows.mano) + 1
        dwmGeneratedControlNo = f"{dwm}-{dwmCnt:04}"
    db.Module.closeqry()
    return dwmGeneratedControlNo 


def Run_dischargePage(master, switch_frame, root):
    app = DischargeApp(master, switch_frame, root)
    app.pack(side= LEFT, fill = BOTH, expand=True)
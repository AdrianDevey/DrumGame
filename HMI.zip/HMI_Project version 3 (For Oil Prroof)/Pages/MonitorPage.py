from datetime import datetime
from textwrap import fill
from tkinter import *
from tkinter import font
from tkinter import messagebox
from tkinter.font import BOLD, ITALIC

from Database import module_v2 as db
from OilProof import OilProofPLC
#from Tools import Connection_PLC as plc
from Tools import MachineInfo


class MonitorApp(Frame):
    def __init__(self, master, switch_frame, root):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame
        self.root = root
        self.running = False
        
        #region -- OLD MONITOR LAYOUT --
        # frameMonitor = Frame(self)
        

        # # Page Title
        # lblMonitor = Label(frameMonitor, text = "Monitor", font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        # lblMonitor.pack(side = TOP, fill= BOTH)

        # lblStatus = Label(frameMonitor, text = "Status:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        # lblTemp = Label(frameMonitor, text = "Temperature:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        
        # lblFluxHeight = Label(frameMonitor, text = "Flux Height:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        # lblSolderHeight = Label(frameMonitor, text = "Solder Height:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        # lblResistance1 = Label(frameMonitor, text = "Resistance 1:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        # lblTempSolderBath = Label(frameMonitor, text = "Temp Solder Bath:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        # lblTempSolderHeater = Label(frameMonitor, text = "Temp Solder Heater:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        # lblTemp3 =  Label(frameMonitor, text = "Temp 3:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        # lblTemp4 = Label(frameMonitor, text = "Temp 4:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = "w")
        
        # lblStatus.pack(side = LEFT, fill= BOTH)
        # lblTemp.pack(side = LEFT, fill= BOTH)

        # lblFluxHeight.pack(side = LEFT, fill= BOTH)
        # lblSolderHeight.pack(side = LEFT, fill= BOTH)
        # lblResistance1.pack(side = LEFT, fill= BOTH)
        # lblTempSolderBath.pack(side = LEFT, fill= BOTH)
        # lblTempSolderHeater.pack(side = LEFT, fill= BOTH)
        # lblTemp3.pack(side = LEFT, fill= BOTH)
        # lblTemp4.pack(side = LEFT, fill= BOTH)
        

        # lblStatus.place(x = 25, y = 50)
        # lblTemp.place(x = 25, y = 90)

        # lblFluxHeight.place(x = 25, y = 170)
        # lblSolderHeight.place(x = 25, y = 210)
        # lblResistance1.place(x = 25, y = 250)
        # lblTempSolderBath.place(x = 25, y = 290)
        # lblTempSolderHeater.place(x = 25, y = 330)
        # lblTemp3.place(x = 25, y = 370)
        # lblTemp4.place(x = 25, y = 410)
        
        # self.status = Label(frameMonitor, text= 'Offline', height= 1, font = ("Bahnschrift", 15, BOLD, ITALIC), fg="Red")
        # self.temp = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")

        # self.fluxHeight = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        # self.solderHeight = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        # self.resistance1 = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        # self.tempSolderBath = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        # self.tempSolderHeater = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        # self.temp3 = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        # self.temp4 = Label(frameMonitor, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        
        # self.status.pack(side=LEFT, fill= BOTH)
        # self.temp.pack(side=LEFT, fill= BOTH)

        # self.fluxHeight.pack(side=LEFT, fill= BOTH)
        # self.solderHeight.pack(side=LEFT, fill= BOTH)
        # self.resistance1.pack(side=LEFT, fill= BOTH)
        # self.tempSolderBath.pack(side=LEFT, fill= BOTH)
        # self.tempSolderHeater.pack(side=LEFT, fill= BOTH)
        # self.temp3.pack(side=LEFT, fill= BOTH)
        # self.temp4.pack(side=LEFT, fill= BOTH)
        
        
        # self.status.place(x= 200, y = 50)
        # self.temp.place(x= 200, y = 90)

        # self.fluxHeight.place(x= 250, y = 170)
        # self.solderHeight.place(x= 250, y = 210)
        # self.resistance1.place(x= 250, y = 250)
        # self.tempSolderBath.place(x= 250, y = 290)
        # self.tempSolderHeater.place(x= 250, y = 330)
        # self.temp3.place(x= 250, y = 370)
        # self.temp4.place(x= 250, y = 410)

        # self.line = Canvas(frameMonitor, width = 700, height = 1, bg = "Gray")
        # self.line.pack()
        # self.line.place( x = 25, y=125)

        # self.label = Label(frameMonitor, text= 'Sample Data from Soldering Machine 17', height= 1, font = ("Bahnschrift", 15, BOLD), fg="Black")
        # self.label.pack()
        # self.label.place(x=25, y= 130)
        
        # ### -- Run Page Buttons -- #########################################################################################################
        # btnFrame = Frame(frameMonitor, height=50)

        # btnStop = Button(btnFrame, text = "Stop", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Stop)
        # btnStop.pack(padx=10)

        # btnReset = Button(btnFrame, text = "Reset", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER)
        # btnReset.pack(padx=10)

        # btnStart = Button(btnFrame, text = "Start", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Start)
        # btnStart.pack(padx=10)

        # btnStop.place(x = 0, y = 0)
        # btnReset.place(x = 275, y = 0)
        # btnStart.place(x = 548, y = 0)

        # btnFrame.pack(side = BOTTOM, expand=False, fill = BOTH)

        # frameMonitor.pack(side = TOP, fill = BOTH, expand=True, padx = 10, pady = 10)
        # frameMonitor.pack_propagate(False)
        # frameMonitor.configure(height=600, width=1024)

        #endregion
        
        if MachineInfo.division == "P1-Cooling" and MachineInfo.section == "Oil Proof":
            MonitorApp.Oil_Proof_Monitor_v2(self)
            MonitorApp.Start(self)
        else:
            MonitorApp.Monitor_Details(self)
        

    def Monitor_Details(self):
        frameMonitor = Frame(self)
        frameMonitor.pack(side = TOP, fill = BOTH, expand=True, padx = 10, pady = 10)
        frameMonitor.pack_propagate(False)
        frameMonitor.configure(height=600, width=1024)

        monitorDetailsFrame = Frame(frameMonitor)
        monitorDetailsFrame.pack(side=TOP, fill=X, expand=False)

        # Page Title
        lblMaintenance = Label(monitorDetailsFrame, text = "Monitor", font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblMaintenance.pack(side = TOP, fill= BOTH, padx=(15,0), pady=(15, 0))

        line = Canvas(monitorDetailsFrame, width = 730, height = 1, bg = "Gray")
        line.pack()

        detailsFrame = Frame(monitorDetailsFrame,)
        detailsFrame.pack(side = TOP, fill = X, expand= False)

        # Parameter Labels
        lblStatus = Label(detailsFrame, text = "Status:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblTemp = Label(detailsFrame, text = "Temperature:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)

        lblFluxHeight = Label(detailsFrame, text = "Flux Height:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblSolderHeight = Label(detailsFrame, text = "Solder Height:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblResistance1 = Label(detailsFrame, text = "Resistance 1:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblResistance2 = Label(detailsFrame, text = "Resistance 2:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblTempSolderBath = Label(detailsFrame, text = "Temp Solder Bath:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblTempSolderHeater = Label(detailsFrame, text = "Temp Solder Heater:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblTemp3 =  Label(detailsFrame, text = "Temp 3:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lblTemp4 = Label(detailsFrame, text = "Temp 4:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)

        lblStatus.grid(row=0, column=0, padx=(30,0), pady=(15,20), sticky=NW)
        lblFluxHeight.grid(row=1, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lblSolderHeight.grid(row=2, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lblResistance1.grid(row=3, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lblResistance2.grid(row=4, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lblTempSolderBath.grid(row=5, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lblTempSolderHeater.grid(row=6, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lblTemp3.grid(row=7, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lblTemp4.grid(row=8, column=0, padx=(30,0), pady=(0,5), sticky=NW)


        # Parameter Data (Value)
        self.status = Label(detailsFrame, text= 'Offline', height= 1, font = ("Bahnschrift", 15, BOLD, ITALIC), fg="Red")
        self.temp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")

        self.fluxHeight = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.solderHeight = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.resistance1 = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.resistance2 = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.tempSolderBath = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.tempSolderHeater = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.temp3 = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.temp4 = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        
        
        self.status.grid(row=0, column=1, padx=(15,0), pady=(15,20), sticky=NW)
        self.fluxHeight.grid(row=1, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        self.solderHeight.grid(row=2, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        self.resistance1.grid(row=3, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        self.resistance2.grid(row=4, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        self.tempSolderBath.grid(row=5, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        self.tempSolderHeater.grid(row=6, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        self.temp3.grid(row=7, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        self.temp4.grid(row=8, column=1, padx=(15,0), pady=(0,5), sticky=NW)

        btnFrame = Frame(frameMonitor, height=50)

        btnStop = Button(btnFrame, text = "Stop", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Stop)
        btnStop.pack(padx=10)

        btnReset = Button(btnFrame, text = "Reset", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER)
        btnReset.pack(padx=10)

        btnStart = Button(btnFrame, text = "Start", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Start)
        btnStart.pack(padx=10)

        btnStop.place(x = 0, y = 0)
        btnReset.place(x = 275, y = 0)
        btnStart.place(x = 548, y = 0)

        btnFrame.pack(side = BOTTOM, expand=False, fill = BOTH)

        

    def Oil_Proof_Monitor(self):
        frameMonitor = Frame(self)
        frameMonitor.pack(side = TOP, fill = BOTH, expand=True, padx = 10, pady = 10)
        frameMonitor.pack_propagate(False)
        frameMonitor.configure(height=600, width=1024)

        monitorDetailsFrame = Frame(frameMonitor)
        monitorDetailsFrame.pack(side=TOP, fill=X, expand=False)

        # Page Title
        lblMaintenance = Label(monitorDetailsFrame, text = "EPOXY INJECTION MACHINE  33", font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblMaintenance.pack(side = TOP, fill= BOTH, padx=(15,0), pady=(15, 0))

        line = Canvas(monitorDetailsFrame, width = 730, height = 1, bg = "Gray")
        line.pack()

        detailsFrame = Frame(monitorDetailsFrame,)
        detailsFrame.pack(side = TOP, fill = X, expand= False)

        # Parameter Labels
        lbl_Status = Label(detailsFrame, text = "Status:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_Monitoring = Label(detailsFrame, text = "Monitoring", font = ("Bahnschrift", 16, BOLD), justify = LEFT, fg="Black", anchor = NW)
        lbl_aLiquid = Label(detailsFrame, text = "A Liquid", font = ("Bahnschrift", 16, BOLD), justify = LEFT, fg="Black", anchor = NW)
        lbl_bLiquid = Label(detailsFrame, text = "B Liquid", font = ("Bahnschrift", 16, BOLD), justify = LEFT, fg="Black", anchor = NW)

        lbl_detailsOfTemp = Label(detailsFrame, text = "Details of Temp.", font = ("Bahnschrift", 16, BOLD), justify = LEFT, fg="Black", anchor = NW)
        lbl_aLiquid2 = Label(detailsFrame, text = "A Liquid", font = ("Bahnschrift", 16, BOLD), justify = LEFT, fg="Black", anchor = NW)
        lbl_bLiquid2 = Label(detailsFrame, text = "B Liquid", font = ("Bahnschrift", 16, BOLD), justify = LEFT, fg="Black", anchor = NW)

        lbl_Status.grid(row=0, column=0, padx=(30,0), pady=(15,20), sticky=NW)
        lbl_Monitoring.grid(row=1, column=0, padx=(30,0), pady=(5, 10), sticky=NW)
        lbl_aLiquid.grid(row=1, column=1, padx=(15,0), pady=(5, 10), sticky=NW)
        lbl_bLiquid.grid(row=1, column=2, padx=(15,0), pady=(5, 10), sticky=NW)
        lbl_detailsOfTemp.grid(row=1, column=4, padx=0, pady=(5, 10), sticky=NW)
        lbl_aLiquid2.grid(row=1, column=5, padx=(15,0), pady=(5, 10), sticky=NW)
        lbl_bLiquid2.grid(row=1, column=6, padx=(15,0), pady=(5, 10), sticky=NW)

        # Parameter Data (Value)
        self.status = Label(detailsFrame, text= 'Monitoring Offline', height= 1, font = ("Bahnschrift", 15, BOLD, ITALIC), fg="Red")

        #region -- Monitoring --
        lbl_tankTemp = Label(detailsFrame, text = "Tank Temp.:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_pumpRev = Label(detailsFrame, text = "Pump Rev.:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_pumpPres = Label(detailsFrame, text = "Pump Pres:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_motionVal = Label(detailsFrame, text = "Motion Val.:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_returnVal= Label(detailsFrame, text = "Return Val:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_mixRise = Label(detailsFrame, text = "Mix Rise:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)


        lbl_tankTemp.grid(row=2, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_pumpRev.grid(row=3, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_pumpPres.grid(row=4, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_motionVal.grid(row=5, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_returnVal.grid(row=6, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_mixRise.grid(row=7, column=0, padx=(30,0), pady=(0,5), sticky=NW)


        # -- A Liquid -- 
        self.aTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.aPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.aPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.aMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.aReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.mixRise = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")

        # -- B Liquid --
        self.bTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.bPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.bPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.bMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.bReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")



        self.status.grid(row=0, column=1, padx=(15,0), pady=(15,20), sticky=NW, columnspan= 7)

        # -- A Liquid --
        #original padx -  padx(15,0)
        self.aTankTemp.grid(row=2, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aPumpRev.grid(row=3, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aPumpPres.grid(row=4, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aMotionVal.grid(row=5, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aReturnVal.grid(row=6, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.mixRise.grid(row=7, column=1, padx=(0,0), pady=(0,5), sticky=NSEW, columnspan=2)

        # -- B Liquid --
        self.bTankTemp.grid(row=2, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bPumpRev.grid(row=3, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bPumpPres.grid(row=4, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bMotionVal.grid(row=5, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bReturnVal.grid(row=6, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        #endregion
        
        line = Canvas(detailsFrame, width = 2, height = 300, bg = "Gray")
        line.grid(row=1, column=3, padx=5, pady=(5, 0), sticky=NW, rowspan=7)

        #region -- Details of Temperature --
        lbl_tankLiquid = Label(detailsFrame, text = "Tank Liquid:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_tankRoom = Label(detailsFrame, text = "Tank Room:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_HoseTemp = Label(detailsFrame, text = "Hose Temp:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
        lbl_mixingHead = Label(detailsFrame, text = "Mixing Head:", font = ("Bahnschrift", 16), justify = LEFT, fg="Black", anchor = NW)
      
        lbl_tankLiquid.grid(row=2, column=4, padx=0, pady=(0,5), sticky=NW)
        lbl_tankRoom.grid(row=3, column=4, padx=0, pady=(0,5), sticky=NW)
        lbl_HoseTemp.grid(row=4, column=4, padx=0, pady=(0,5), sticky=NW)
        lbl_mixingHead.grid(row=5, column=4, padx=0, pady=(0,5), sticky=NW)

        # -- A Liquid --
        self.aTankLiquid= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.aTankRoom= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.aHoseTemp= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.mixingHead= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")

        self.aTankLiquid.grid(row=2, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aTankRoom.grid(row=3, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aHoseTemp.grid(row=4, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.mixingHead.grid(row=5, column=5, padx=(0,0), pady=(0,5), sticky=NSEW, columnspan=2)

        # -- B Liquid --
        self.bTankLiquid = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.bTankRoom = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")
        self.bHoseTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 15), fg="Black")

        self.bTankLiquid.grid(row=2, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bTankRoom.grid(row=3, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bHoseTemp.grid(row=4, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        
        #self.aPumpRev.grid(row=3, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        #endregion

        btnFrame = Frame(frameMonitor, height=50)

        btnStop = Button(btnFrame, text = "Stop", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Stop)
        btnStop.pack(padx=10)

        btnReset = Button(btnFrame, text = "Reset", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER)
        btnReset.pack(padx=10)

        btnStart = Button(btnFrame, text = "Start", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Start)
        btnStart.pack(padx=10)

        btnStop.place(x = 0, y = 0)
        btnReset.place(x = 275, y = 0)
        btnStart.place(x = 548, y = 0)

        btnFrame.pack(side = BOTTOM, expand=False, fill = BOTH)
        
    def Oil_Proof_Monitor_v2(self):
        frameMonitor = Frame(self)
        frameMonitor.pack(side = TOP, fill = BOTH, expand=True, padx = 10, pady = 10)
        frameMonitor.pack_propagate(False)
        frameMonitor.configure(height=600, width=1024)

        monitorDetailsFrame = Frame(frameMonitor)
        monitorDetailsFrame.pack(side=TOP, fill=X, expand=False)

        # Page Title
        lblMaintenance = Label(monitorDetailsFrame, text = MachineInfo.machineName, font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblMaintenance.pack(side = TOP, fill= BOTH, padx=(15,0), pady=(15, 0))

        line = Canvas(monitorDetailsFrame, width = 730, height = 1, bg = "Gray")
        line.pack()

        detailsFrame = Frame(monitorDetailsFrame,)
        detailsFrame.pack(side = TOP, fill = X, expand= False)

        # Parameter Labels
        lbl_MachineStatus = Label(detailsFrame, text = "Machine Status:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_Monitoring = Label(detailsFrame, text = "Monitoring", font = ("Bahnschrift", 12, BOLD), justify = LEFT, fg="Black", anchor = NW)
        lbl_aLiquid = Label(detailsFrame, text = "A Liquid", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width=8)
        lbl_UCL1= Label(detailsFrame, text = "UCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)
        lbl_LCL1 = Label(detailsFrame, text = "LCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)
        
        lbl_bLiquid = Label(detailsFrame, text = "B Liquid", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width=8)
        lbl_UCL2= Label(detailsFrame, text = "UCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)
        lbl_LCL2 = Label(detailsFrame, text = "LCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)

        lbl_detailsOfTemp = Label(detailsFrame, text = "Details of Temp.", font = ("Bahnschrift", 12, BOLD), justify = LEFT, fg="Black", anchor = NW)
        lbl_aLiquid2 = Label(detailsFrame, text = "A Liquid", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width=8)
        lbl_UCL3= Label(detailsFrame, text = "UCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)
        lbl_LCL3 = Label(detailsFrame, text = "LCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)
        
        lbl_bLiquid2 = Label(detailsFrame, text = "B Liquid", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width=8)
        lbl_UCL4= Label(detailsFrame, text = "UCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)
        lbl_LCL4 = Label(detailsFrame, text = "LCL", font = ("Bahnschrift", 12, BOLD), justify = CENTER, fg="Black", anchor = CENTER, width = 8)

        lbl_MachineStatus.grid(row=0, column=0, padx=(30,0), pady=(20,15), sticky=NW)
        lbl_Monitoring.grid(row=1, column=0, padx=(30,0), pady=(5, 10), sticky=NW)
        
        lbl_aLiquid.grid(row=1, column=1, padx=(0), pady=(5, 10), sticky=NSEW)
        lbl_UCL1.grid(row=1, column=2, padx=(0), pady=(5, 10), sticky=NSEW)
        lbl_LCL1.grid(row=1, column=3, padx=(0), pady=(5, 10), sticky=NSEW)
        
        lbl_bLiquid.grid(row=1, column=5, padx=(0), pady=(5, 10), sticky=NSEW)
        lbl_UCL2.grid(row=1, column=6, padx=(0), pady=(5, 10), sticky=NSEW)
        lbl_LCL2.grid(row=1, column=7, padx=(0), pady=(5, 10), sticky=NSEW)

        lbl_detailsOfTemp.grid(row=8, column=0, padx=(30,15), pady=(5, 10), sticky=NW)
        lbl_aLiquid2.grid(row=8, column=1, padx=(0), pady=(5, 10), sticky=NW)
        lbl_UCL3.grid(row=8, column=2, padx=(0), pady=(5, 10), sticky=NSEW)
        lbl_LCL3.grid(row=8, column=3, padx=(0), pady=(5, 10), sticky=NSEW)


        lbl_bLiquid2.grid(row=8, column=5, padx=(0), pady=(5, 10), sticky=NW)
        lbl_UCL4.grid(row=8, column=6, padx=(0), pady=(5, 10), sticky=NSEW)
        lbl_LCL4.grid(row=8, column=7, padx=(0), pady=(5, 10), sticky=NSEW)


        btn_controlLimit = Button(detailsFrame, text = "Set Control Limit", font = ("Bahnschrift", 12, BOLD, ITALIC), fg="Black",   bd = 0,  height=1, justify=CENTER, command= self.Control_Limit)
        btn_controlLimit.grid(row=0, column=5, padx=(0), pady=(20,15), sticky=NE, columnspan =3)

        # Parameter Data (Value)
        self.machineStatus = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12, BOLD, ITALIC))

        #region -- Monitoring --
        lbl_tankTemp = Label(detailsFrame, text = "Tank Temp.:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_pumpRev = Label(detailsFrame, text = "Pump Rev.:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_pumpPres = Label(detailsFrame, text = "Pump Pres:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_motionVal = Label(detailsFrame, text = "Motion Val.:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_returnVal= Label(detailsFrame, text = "Return Val:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_mixRise = Label(detailsFrame, text = "Mix Rise:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)


        lbl_tankTemp.grid(row=2, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_pumpRev.grid(row=3, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_pumpPres.grid(row=4, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_motionVal.grid(row=5, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_returnVal.grid(row=6, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_mixRise.grid(row=7, column=0, padx=(30,0), pady=(0,5), sticky=NW)


        # -- A Liquid -- 
        self.aTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.aPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.aPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.aMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.aReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.mixRise = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        
        #region -- A Liquid Control Limit --
        self.ucl_aTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_aPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_aPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_aMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_aReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_mixRise = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")

        self.lcl_aTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_aPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_aPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_aMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_aReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_mixRise = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        #endregion

        # -- B Liquid --
        self.bTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.bPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.bPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.bMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.bReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")

        #region -- B Liquid Control Limit Label --
        self.ucl_bTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_bPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_bPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_bMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_bReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")

        self.lcl_bTankTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_bPumpRev = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_bPumpPres = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_bMotionVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_bReturnVal = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        #endregion

        self.machineStatus.grid(row=0, column=1, padx=(0), pady=(20,15), sticky=NW, columnspan= 3)

        # -- A Liquid --
        #original padx -  padx(15,0)
        self.aTankTemp.grid(row=2, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aPumpRev.grid(row=3, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aPumpPres.grid(row=4, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aMotionVal.grid(row=5, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aReturnVal.grid(row=6, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.mixRise.grid(row=7, column=1, padx=(0,0), pady=(0,5), sticky=NSEW, columnspan=3)

        #region -- A Liquid Control Limit Grid --
        self.ucl_aTankTemp.grid(row=2, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_aPumpRev.grid(row=3, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_aPumpPres.grid(row=4, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_aMotionVal.grid(row=5, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_aReturnVal.grid(row=6, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        
        self.lcl_aTankTemp.grid(row=2, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_aPumpRev.grid(row=3, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_aPumpPres.grid(row=4, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_aMotionVal.grid(row=5, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_aReturnVal.grid(row=6, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        #endregion
        line = Canvas(detailsFrame, width = 2, height = 170, bg = "Gray")
        line.grid(row=2, column=4, padx=(10, 30), pady=0, sticky=NW, rowspan=6)

        # -- B Liquid --
        self.bTankTemp.grid(row=2, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bPumpRev.grid(row=3, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bPumpPres.grid(row=4, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bMotionVal.grid(row=5, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bReturnVal.grid(row=6, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)

        #region -- B Liquid Control Limit Grid --
        self.ucl_bTankTemp.grid(row=2, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_bPumpRev.grid(row=3, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_bPumpPres.grid(row=4, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_bMotionVal.grid(row=5, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_bReturnVal.grid(row=6, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)

        self.lcl_bTankTemp.grid(row=2, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_bPumpRev.grid(row=3, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_bPumpPres.grid(row=4, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_bMotionVal.grid(row=5, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_bReturnVal.grid(row=6, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)
        #endregion



        #endregion
        
        
        #region -- Details of Temperature --
        lbl_tankLiquid = Label(detailsFrame, text = "Tank Liquid:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_tankRoom = Label(detailsFrame, text = "Tank Room:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_HoseTemp = Label(detailsFrame, text = "Hose Temp:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_mixingHead = Label(detailsFrame, text = "Mixing Head:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
      
        lbl_tankLiquid.grid(row=9, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_tankRoom.grid(row=10, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_HoseTemp.grid(row=11, column=0, padx=(30,0), pady=(0,5), sticky=NW)
        lbl_mixingHead.grid(row=12, column=0, padx=(30,0), pady=(0,5), sticky=NW)

        # -- A Liquid --
        self.aTankLiquid= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.aTankRoom= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.aHoseTemp= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.mixingHead= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")

        #region -- A Liquid Details Control Limit Label --
        self.ucl_aTankLiquid= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_aTankRoom= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_aHoseTemp= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")

        self.lcl_aTankLiquid= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_aTankRoom= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_aHoseTemp= Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        #endregion

        self.aTankLiquid.grid(row=9, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aTankRoom.grid(row=10, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.aHoseTemp.grid(row=11, column=1, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.mixingHead.grid(row=12, column=1, padx=(0,0), pady=(0,5), sticky=NSEW, columnspan=3)

        #region -- A Liquin Details Control Limit Grid --
        self.ucl_aTankLiquid.grid(row=9, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_aTankRoom.grid(row=10, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_aHoseTemp.grid(row=11, column=2, padx=(0,0), pady=(0,5), sticky=NSEW)

        self.lcl_aTankLiquid.grid(row=9, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_aTankRoom.grid(row=10, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_aHoseTemp.grid(row=11, column=3, padx=(0,0), pady=(0,5), sticky=NSEW)
        #endregion

        line = Canvas(detailsFrame, width = 2, height = 100, bg = "Gray")
        line.grid(row=9, column=4, padx=(10, 30), pady=0, sticky=NW, rowspan=6)

        # -- B Liquid --
        self.bTankLiquid = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.bTankRoom = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.bHoseTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")

        #region -- B Liquid Details Control Limit Label --
        self.ucl_bTankLiquid = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_bTankRoom = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.ucl_bHoseTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")

        self.lcl_bTankLiquid = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_bTankRoom = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        self.lcl_bHoseTemp = Label(detailsFrame, text= '---', height= 1, font = ("Bahnschrift", 12), fg="Black")
        #endregion

        self.bTankLiquid.grid(row=9, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bTankRoom.grid(row=10, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.bHoseTemp.grid(row=11, column=5, padx=(0,0), pady=(0,5), sticky=NSEW)
        
        self.ucl_bTankLiquid.grid(row=9, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_bTankRoom.grid(row=10, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.ucl_bHoseTemp.grid(row=11, column=6, padx=(0,0), pady=(0,5), sticky=NSEW)

        self.lcl_bTankLiquid.grid(row=9, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_bTankRoom.grid(row=10, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)
        self.lcl_bHoseTemp.grid(row=11, column=7, padx=(0,0), pady=(0,5), sticky=NSEW)

        
        #self.aPumpRev.grid(row=3, column=1, padx=(15,0), pady=(0,5), sticky=NW)
        #endregion

       



        btnFrame = Frame(frameMonitor, height=50)

        btnStop = Button(btnFrame, text = "Stop", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Stop)
        btnStop.pack(padx=10)

        btnReset = Button(btnFrame, text = "Reset", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER,  command=self.Reset)
        btnReset.pack(padx=10)

        btnStart = Button(btnFrame, text = "Start", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER, command= self.Start)
        btnStart.pack(padx=10)

        btnStop.place(x = 0, y = 0)
        btnReset.place(x = 275, y = 0)
        btnStart.place(x = 548, y = 0)

        btnFrame.pack(side = BOTTOM, expand=False, fill = BOTH)
        
    def DataGather(self):
        if self.running:
            db.Module.openquery()
            db.Module.query = "SELECT TOP 1 * FROM RPI_Thermocouple WHERE fldMachineId = ? ORDER BY fldId DESC"
            db.Module.parameter = MachineInfo.machineId
            db.Module.opencommand()
            rows = db.Module.exeReader()
            if rows:
                for row in rows:
                    self.tempSolderBath.config(text =f'{row.fldTemperature} °C')  
                    #print(row.fldTemperature)

            db.Module.closeqry()
            
            #region -- READ KEYENCE PLC PARAMETERS --

            # Read PLC
            # plc.readPLC()

            # db.Module.openquery()
            # db.Module.query = "SELECT TOP 1 * FROM RPI_ReadingPLC WHERE fldId = 1"
            # db.Module.parameter = None
            # db.Module.opencommand()
            # rows = db.Module.exeReader()
            # if rows:
            #     for row in rows:
            #         self.fluxHeight.config(text=f'{row.fldFluxHeight} mm')
            #         self.solderHeight.config(text=f'{row.fldSolderHeight} mm')
            #         #self.tempSolderBath.config(text=f'{row.fldSolderBathTemp} °C')
            #         self.tempSolderHeater.config(text=f'{row.fldSolderHeaterTemp} °C')
            # db.Module.closeqry()

            #endregion -- END - READ KEYENCE PLC PAREMETERS --
             
            self.after(100, self.DataGather)

    def OilProof_DataGather(self):
        if self.running:
            OilProofPLC.Parameters()

            db.Module.openquery()
            db.Module.query = "SELECT TOP 1 * FROM RPI_OilProofMonitoring WHERE fldMachineId = ? ORDER BY fldId DESC"
            db.Module.parameter = MachineInfo.machineId
            db.Module.opencommand()
            plcReader = db.Module.exeReader()
            if plcReader:
                for row in plcReader:
                    if row.fldStatus == 'Standby':
                        self.machineStatus.config(text=row.fldStatus, fg='Orange')
                    elif row.fldStatus == 'Running':
                        self.machineStatus.config(text=row.fldStatus, fg ='Green')
                    
                    


                    # Monitor
                    self.aTankTemp.config(text=row.fldTankTempA)
                    self.bTankTemp.config(text=row.fldTankTempB)

                    self.aPumpRev.config(text=row.fldPumpRevolutionA)
                    self.bPumpRev.config(text=row.fldPumpRevolutionB)

                    self.aPumpPres.config(text=row.fldPumpPresA) 
                    self.bPumpPres.config(text=row.fldPumpPresB)

                    self.aMotionVal.config(text=row.fldMotionValA)
                    self.bMotionVal.config(text=row.fldMotionValB)

                    self.aReturnVal.config(text=row.fldReturnValA)
                    self.bReturnVal.config(text=row.fldReturnValB)

                    self.mixRise.config(text=row.fldMixRise)

                    # Details of Temp
                    self.aTankLiquid.config(text=row.fldTankLiquidA)
                    self.bTankLiquid.config(text=row.fldTankLiquidB)

                    self.aTankRoom.config(text=row.fldTankRoomA)
                    self.bTankRoom.config(text=row.fldTankRoomB)

                    self.aHoseTemp.config(text=row.fldHoseTempA)
                    self.bHoseTemp.config(text=row.fldHoseTempB)

                    self.mixingHead.config(text=row.fldMixingHead)
                    
            self.after(1000, self.OilProof_DataGather)

    def Control_Limit(self):
        global limit_window
        limit_window = Toplevel(self.root)
        #limit_window.geometry("530x465")
        limit_window.title("Control Limit Setup")
        limit_window.resizable(0,0)
        limit_window.attributes('-topmost', 'true')

        topFrame = Frame(limit_window)
        topFrame.pack(side=TOP, fill=X, expand=False)

        lbl = Label(topFrame, text=MachineInfo.machineId, font=("Bahnschrift", 15, BOLD), justify=LEFT, anchor=NW)
        lbl1 = Label(topFrame, text=MachineInfo.machineName, font=("Bahnschrift", 12), justify=LEFT, anchor=NW)

        lbl.grid(row=0, column=0, sticky=NSEW, padx=(15,0))
        lbl1.grid(row=1, column=0, sticky=NSEW, padx=(15,0))

        line = Canvas(topFrame, width = 515, height = 1, bg = "Gray")
        line.grid(row=2, column=0, pady=(0, 15),sticky=NSEW)


        controlFrame = Frame(limit_window)
        controlFrame.pack(fill=BOTH, expand=True)

        lbl_liquidA = Label(controlFrame, text='A Liquid', font=("Bahnschrift", 12, BOLD), justify=CENTER, anchor=CENTER, width=10)
        lbl_ucl = Label(controlFrame, text='UCL', font=("Bahnschrift", 12, BOLD), justify=CENTER, anchor=CENTER, width=10)
        lbl_lcl = Label(controlFrame, text='LCL', font=("Bahnschrift", 12, BOLD), justify=CENTER, anchor=CENTER, width=10)

        lbl_liquidA.grid(row=0, column=1, sticky=NSEW, columnspan=2)
        lbl_ucl.grid(row=1, column=1, sticky=NSEW)
        lbl_lcl.grid(row=1, column=2, sticky=NSEW)

        line = Canvas(controlFrame, width = 2, height = 320, bg = "Gray")
        line.grid(row=1, column=3, padx=(0), pady=0, sticky=NW, rowspan=10)

        lbl_liquidB = Label(controlFrame, text='B Liquid', font=("Bahnschrift", 12, BOLD), justify=CENTER, anchor=CENTER, width=10)
        lbl_ucl2 = Label(controlFrame, text='UCL', font=("Bahnschrift", 12, BOLD), justify=CENTER, anchor=CENTER, width=10)
        lbl_lcl2 = Label(controlFrame, text='LCL', font=("Bahnschrift", 12, BOLD), justify=CENTER, anchor=CENTER, width=10)

        lbl_liquidB.grid(row=0, column=4, sticky=NSEW, columnspan=2)
        lbl_ucl2.grid(row=1, column=4, sticky=NSEW)
        lbl_lcl2.grid(row=1, column=5, sticky=NSEW)




        lbl_tankTemp = Label(controlFrame, text = "Tank Temp.:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_pumpRev = Label(controlFrame, text = "Pump Rev.:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_pumpPres = Label(controlFrame, text = "Pump Pres:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_motionVal = Label(controlFrame, text = "Motion Val.:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_returnVal= Label(controlFrame, text = "Return Val:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)

        lbl_tankTemp.grid(row=2, column=0, padx=(15,0), pady=(0,5), sticky=NW)
        lbl_pumpRev.grid(row=3, column=0, padx=(15,0), pady=(0,5), sticky=NW)
        lbl_pumpPres.grid(row=4, column=0, padx=(15,0), pady=(0,5), sticky=NW)
        lbl_motionVal.grid(row=5, column=0, padx=(15,0), pady=(0,5), sticky=NW)
        lbl_returnVal.grid(row=6, column=0, padx=(15,0), pady=(0,5), sticky=NW)


        lbl_tankLiquid = Label(controlFrame, text = "Tank Liquid:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_tankRoom = Label(controlFrame, text = "Tank Room:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)
        lbl_HoseTemp = Label(controlFrame, text = "Hose Temp:", font = ("Bahnschrift", 12), justify = LEFT, fg="Black", anchor = NW)

        lbl_tankLiquid.grid(row=7, column=0, padx=(15,0), pady=(30,5), sticky=NW)
        lbl_tankRoom.grid(row=8, column=0, padx=(15,0), pady=(0,5), sticky=NW)
        lbl_HoseTemp.grid(row=9, column=0, padx=(15,0), pady=(0,5), sticky=NW)

        global txt_UCLtankTempA, txt_UCLpumpRevA, txt_UCLpumpPresA, txt_UCLmotionValA, txt_UCLreturnValA, txt_UCLtankLiquidA, txt_UCLtankRoomA, txt_UCLhoseTempA
        global txt_LCLtankTempA, txt_LCLpumpRevA, txt_LCLpumpPresA, txt_LCLmotionValA, txt_LCLreturnValA, txt_LCLtankLiquidA, txt_LCLtankRoomA , txt_LCLhoseTempA 

        #region -- A Liquid Textbox --
        txt_UCLtankTempA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLpumpRevA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLpumpPresA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLmotionValA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLreturnValA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLtankLiquidA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLtankRoomA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLhoseTempA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")

        txt_LCLtankTempA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLpumpRevA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLpumpPresA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLmotionValA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLreturnValA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLtankLiquidA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLtankRoomA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLhoseTempA=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")

        txt_UCLtankTempA.grid(row=2, column=1, pady=(0,5), sticky=N)
        txt_UCLpumpRevA.grid(row=3, column=1, pady=(0,5), sticky=N)
        txt_UCLpumpPresA.grid(row=4, column=1, pady=(0,5), sticky=N)
        txt_UCLmotionValA.grid(row=5, column=1, pady=(0,5), sticky=N)
        txt_UCLreturnValA.grid(row=6, column=1, pady=(0,5), sticky=N)
        txt_UCLtankLiquidA.grid(row=7, column=1, pady=(30,5), sticky=N)
        txt_UCLtankRoomA.grid(row=8, column=1, pady=(0,5), sticky=N)
        txt_UCLhoseTempA.grid(row=9, column=1, pady=(0,5), sticky=N)

        txt_LCLtankTempA.grid(row=2, column=2, pady=(0,5), sticky=N)
        txt_LCLpumpRevA.grid(row=3, column=2, pady=(0,5), sticky=N)
        txt_LCLpumpPresA.grid(row=4, column=2, pady=(0,5), sticky=N)
        txt_LCLmotionValA.grid(row=5, column=2, pady=(0,5), sticky=N)
        txt_LCLreturnValA.grid(row=6, column=2, pady=(0,5), sticky=N)
        txt_LCLtankLiquidA.grid(row=7, column=2, pady=(30,5), sticky=N)
        txt_LCLtankRoomA.grid(row=8, column=2, pady=(0,5), sticky=N)
        txt_LCLhoseTempA.grid(row=9, column=2, pady=(0,5), sticky=N)
        #endregion


        global txt_UCLtankTempB, txt_UCLpumpRevB, txt_UCLpumpPresB , txt_UCLmotionValB, txt_UCLreturnValB, txt_UCLtankLiquidB, txt_UCLtankRoomB , txt_UCLhoseTempB
        global txt_LCLtankTempB, txt_LCLpumpRevB, txt_LCLpumpPresB, txt_LCLmotionValB, txt_LCLreturnValB, txt_LCLtankLiquidB, txt_LCLtankRoomB , txt_LCLhoseTempB
        
        #region -- B Liquid Textbox --
        txt_UCLtankTempB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLpumpRevB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLpumpPresB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLmotionValB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLreturnValB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLtankLiquidB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLtankRoomB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_UCLhoseTempB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")

        txt_LCLtankTempB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLpumpRevB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLpumpPresB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLmotionValB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLreturnValB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLtankLiquidB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLtankRoomB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")
        txt_LCLhoseTempB=  Entry(controlFrame, width = 9, font = ("Bahnschrift", 12), fg="Black")

        txt_UCLtankTempB.grid(row=2, column=4, pady=(0,5), sticky=N)
        txt_UCLpumpRevB.grid(row=3, column=4, pady=(0,5), sticky=N)
        txt_UCLpumpPresB.grid(row=4, column=4, pady=(0,5), sticky=N)
        txt_UCLmotionValB.grid(row=5, column=4, pady=(0,5), sticky=N)
        txt_UCLreturnValB.grid(row=6, column=4, pady=(0,5), sticky=N)
        txt_UCLtankLiquidB.grid(row=7, column=4, pady=(30,5), sticky=N)
        txt_UCLtankRoomB.grid(row=8, column=4, pady=(0,5), sticky=N)
        txt_UCLhoseTempB.grid(row=9, column=4, pady=(0,5), sticky=N)

        txt_LCLtankTempB.grid(row=2, column=5, pady=(0,5), sticky=N)
        txt_LCLpumpRevB.grid(row=3, column=5, pady=(0,5), sticky=N)
        txt_LCLpumpPresB.grid(row=4, column=5, pady=(0,5), sticky=N)
        txt_LCLmotionValB.grid(row=5, column=5, pady=(0,5), sticky=N)
        txt_LCLreturnValB.grid(row=6, column=5, pady=(0,5), sticky=N)
        txt_LCLtankLiquidB.grid(row=7, column=5, pady=(30,5), sticky=N)
        txt_LCLtankRoomB.grid(row=8, column=5, pady=(0,5), sticky=N)
        txt_LCLhoseTempB.grid(row=9, column=5, pady=(0,5), sticky=N)
        #endregion



        btnUpdate = Button(limit_window, text = "Update Control Limit", font = ("Bahnschrift", 12, BOLD), fg="white",  bg = "#1253a3",  bd = 0,  height=1, justify=CENTER, command= self.Update_Control_Limit)
        btnUpdate.pack(side=BOTTOM, fill =X, expand=False, padx=5, pady=5)

    def Update_Control_Limit(self):

        UCLtankTempA = txt_UCLtankTempA.get()
        UCLpumpRevA = txt_UCLpumpRevA.get()
        UCLpumpPresA = txt_UCLpumpPresA.get()
        UCLmotionValA = txt_UCLmotionValA.get()
        UCLreturnValA = txt_UCLreturnValA.get()
        UCLtankLiquidA = txt_UCLtankLiquidA.get()
        UCLtankRoomA = txt_UCLtankRoomA.get()
        UCLhoseTempA = txt_UCLhoseTempA.get()

        LCLtankTempA = txt_LCLtankTempA.get()
        LCLpumpRevA = txt_LCLpumpRevA.get()
        LCLpumpPresA = txt_LCLpumpPresA.get()
        LCLmotionValA = txt_LCLmotionValA.get()
        LCLreturnValA = txt_LCLreturnValA.get()
        LCLtankLiquidA = txt_LCLtankLiquidA.get()
        LCLtankRoomA = txt_LCLtankRoomA.get()
        LCLhoseTempA  = txt_LCLhoseTempA.get()

        UCLtankTempB = txt_UCLtankTempB.get()
        UCLpumpRevB   = txt_UCLpumpRevB.get()
        UCLpumpPresB  = txt_UCLpumpPresB.get()
        UCLmotionValB = txt_UCLmotionValB.get()
        UCLreturnValB = txt_UCLreturnValB.get()
        UCLtankLiquidB = txt_UCLtankLiquidB.get()
        UCLtankRoomB  = txt_UCLtankRoomB.get()
        UCLhoseTempB  = txt_UCLhoseTempB.get()

        LCLtankTempB = txt_LCLtankTempB.get()
        LCLpumpRevB = txt_LCLpumpRevB.get()
        LCLpumpPresB = txt_LCLpumpPresB.get()
        LCLmotionValB = txt_LCLmotionValB.get()
        LCLreturnValB = txt_LCLreturnValB.get()
        LCLtankLiquidB = txt_LCLtankLiquidB.get()
        LCLtankRoomB = txt_LCLtankRoomB.get()
        LCLhoseTempB = txt_LCLhoseTempB.get()


        if UCLtankTempA != "" and UCLpumpRevA != "" and UCLpumpPresA != "" and UCLmotionValA != "" and UCLreturnValA != "" and UCLtankLiquidA != "" and UCLtankRoomA != "" and UCLhoseTempA != "" and LCLtankTempA != "" and LCLpumpRevA != "" and LCLpumpPresA != "" and LCLmotionValA != "" and LCLreturnValA != "" and LCLtankLiquidA != "" and LCLtankRoomA != "" and LCLhoseTempA != "" and UCLtankTempB != "" and UCLpumpRevB != "" and UCLpumpPresB != "" and UCLmotionValB != "" and UCLreturnValB != "" and UCLtankLiquidB != "" and UCLtankRoomB != "" and UCLhoseTempB != "" and LCLtankTempB != "" and LCLpumpRevB != "" and LCLpumpPresB != "" and LCLmotionValB != "" and LCLreturnValB != "" and LCLtankLiquidB != "" and LCLtankRoomB != "" and LCLhoseTempB != "":

            if is_float(UCLtankTempA) and is_float(UCLpumpRevA) and is_float(UCLpumpPresA) and is_float(UCLmotionValA) and is_float(UCLreturnValA) and is_float(UCLtankLiquidA) and is_float(UCLtankRoomA) and is_float(UCLhoseTempA) and is_float(LCLtankTempA) and is_float(LCLpumpRevA) and is_float(LCLpumpPresA) and is_float(LCLmotionValA ) and is_float(LCLreturnValA) and is_float(LCLtankLiquidA) and is_float(LCLtankRoomA) and is_float(LCLhoseTempA) and is_float(UCLtankTempB) and is_float(UCLpumpRevB) and is_float(UCLpumpPresB) and is_float(UCLmotionValB) and is_float(UCLreturnValB) and is_float(UCLtankLiquidB) and is_float(UCLtankRoomB) and is_float(UCLhoseTempB) and is_float(LCLtankTempB) and is_float(LCLpumpRevB) and is_float(LCLpumpPresB) and is_float(LCLmotionValB) and is_float(LCLreturnValB) and is_float(LCLtankLiquidB) and is_float(LCLtankRoomB) and is_float(LCLhoseTempB):
                
                Generate_Unique_ID()
                
                db.Module.openquery()
                db.Module.query = '''
                    INSERT INTO RPI_ControlLimit (
                        fldUniqueId, fldMachineId, fldDate, fldTankTemp_upA, fldTankTemp_lowA, fldTankTemp_upB, fldTankTemp_lowB, 
                        fldPumpRevolution_upA, fldPumpRevolution_lowA, fldPumpRevolution_upB, fldPumpRevolution_lowB, fldPumpPres_upA, 
                        fldPumpPres_lowA, fldPumpPres_upB, fldPumpPres_lowB, fldMotionVal_upA, fldMotionVal_lowA, fldMotionVal_upB, 
                        fldMotionVal_lowB, fldReturnVal_upA, fldReturnVal_lowA, fldReturnVal_upB, fldReturnVal_lowB, fldTankLiquid_upA, 
                        fldTankLiquid_lowA, fldTankLiquid_upB, fldTankLiquid_lowB, fldTankRoom_upA, fldTankRoom_lowA, fldTankRoom_upB,
                        fldTankRoom_lowB, fldHoseTemp_upA, fldHoseTemp_lowA, fldHoseTemp_upB, fldHoseTemp_lowB
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                '''
                db.Module.parameter = ()
                parameter = list(db.Module.parameter)
                parameter.append(clGeneratedControlNo)
                parameter.append(MachineInfo.machineId)
                parameter.append(datetime.now())
                parameter.append(UCLtankTempA)
                parameter.append(LCLtankTempA)
                parameter.append(UCLtankTempB)
                parameter.append(LCLtankTempB)
                parameter.append(UCLpumpRevA)
                parameter.append(LCLpumpRevA)
                parameter.append(UCLpumpRevB)
                parameter.append(LCLpumpRevB)
                parameter.append(UCLpumpPresA)
                parameter.append(LCLpumpPresA)
                parameter.append(UCLpumpPresB)
                parameter.append(LCLpumpPresB)
                parameter.append(UCLmotionValA)
                parameter.append(LCLmotionValA)
                parameter.append(UCLmotionValB)
                parameter.append(LCLmotionValB)
                parameter.append(UCLreturnValA)
                parameter.append(LCLreturnValA)
                parameter.append(UCLreturnValB)
                parameter.append(LCLreturnValB)
                parameter.append(UCLtankLiquidA)
                parameter.append(LCLtankLiquidA)
                parameter.append(UCLtankLiquidB)
                parameter.append(LCLtankLiquidB)
                parameter.append(UCLtankRoomA)
                parameter.append(LCLtankRoomA)
                parameter.append(UCLtankRoomB)
                parameter.append(LCLtankRoomB)
                parameter.append(UCLhoseTempA)
                parameter.append(LCLhoseTempA)
                parameter.append(UCLhoseTempB)
                parameter.append(LCLhoseTempB)
                db.Module.parameter = tuple(parameter)
                db.Module.opencommand()
                db.Module.conn.commit()
                db.Module.closeqry()

                
                
                
                limit_window.destroy()
                self.destroy()
                Run_MonitorPage(self.master, self.switch_frame, self.root)
            else:
                messagebox.showerror("Invalid Input", "Fields must contaon only numbers. Please check and try again.")

        else:
            messagebox.showerror("Missing Fields", "Please fill all empty fields")


        



        

    def Start(self):
        if not self.running:
            self.running = True
            #self.status.config(text = "Running", fg = "Green")

            if MachineInfo.division == "P1-Cooling" and MachineInfo.section == "Oil Proof":
                self.OilProof_DataGather()

                #region -- Conrol Limit --
                db.Module.openquery()
                db.Module.query = "SELECT TOP 1 * FROM RPI_ControlLimit WHERE fldMachineId = ? ORDER BY fldDate DESC"
                db.Module.parameter = MachineInfo.machineId
                db.Module.opencommand()
                limitReader = db.Module.exeReader()
                if limitReader:
                    for row in limitReader:
                        self.ucl_aTankTemp.config(text=row.fldTankTemp_upA)
                        self.ucl_aPumpRev.config(text=row.fldPumpRevolution_upA)
                        self.ucl_aPumpPres.config(text=row.fldPumpPres_upA)
                        self.ucl_aMotionVal.config(text=row.fldMotionVal_upA)
                        self.ucl_aReturnVal.config(text=row.fldReturnVal_upA)
        
                        self.lcl_aTankTemp.config(text=row.fldTankTemp_lowA)
                        self.lcl_aPumpRev.config(text=row.fldPumpRevolution_lowA)
                        self.lcl_aPumpPres.config(text=row.fldPumpPres_lowA)
                        self.lcl_aMotionVal.config(text=row.fldMotionVal_lowA)
                        self.lcl_aReturnVal.config(text=row.fldReturnVal_lowA)
        
                        self.ucl_bTankTemp.config(text=row.fldTankTemp_upB)
                        self.ucl_bPumpRev.config(text=row.fldPumpRevolution_upB)
                        self.ucl_bPumpPres.config(text=row.fldPumpPres_upB)
                        self.ucl_bMotionVal.config(text=row.fldMotionVal_upB)
                        self.ucl_bReturnVal.config(text=row.fldReturnVal_upB)
        
                        self.lcl_bTankTemp.config(text=row.fldTankTemp_lowB)
                        self.lcl_bPumpRev.config(text=row.fldPumpRevolution_lowB)
                        self.lcl_bPumpPres.config(text=row.fldPumpPres_lowB)
                        self.lcl_bMotionVal.config(text=row.fldMotionVal_lowB)
                        self.lcl_bReturnVal.config(text=row.fldReturnVal_lowB)
            
                        self.ucl_aTankLiquid.config(text=row.fldTankLiquid_upA)
                        self.ucl_aTankRoom.config(text=row.fldTankRoom_upA)
                        self.ucl_aHoseTemp.config(text=row.fldHoseTemp_upA)
        
                        self.lcl_aTankLiquid.config(text=row.fldTankLiquid_lowA)
                        self.lcl_aTankRoom.config(text=row.fldTankRoom_lowA)
                        self.lcl_aHoseTemp.config(text=row.fldHoseTemp_lowA)
        
                        self.ucl_bTankLiquid.config(text=row.fldTankLiquid_upB)
                        self.ucl_bTankRoom.config(text=row.fldTankRoom_upB)
                        self.ucl_bHoseTemp.config(text=row.fldHoseTemp_upB)
        
                        self.lcl_bTankLiquid.config(text=row.fldTankLiquid_lowB)
                        self.lcl_bTankRoom.config(text=row.fldTankRoom_lowB)
                        self.lcl_bHoseTemp.config(text=row.fldHoseTemp_lowB)
        
                db.Module.closeqry()
                #endregion

            else:
                self.DataGather()


    def Stop(self):
        self.running = False
        #self.status.config(text = "Monitoring Offline", fg = "Red")
        self.machineStatus.config(text="---", fg = 'Black')

    def Reset(self):
        self.running = False
        #self.status.config(text = "Monitoring Offline", fg = "Red")
        self.machineStatus.config(text="---", fg = 'Black')
        
        self.aTankTemp.config(text="---")
        self.aPumpRev.config(text="---")
        self.aPumpPres.config(text="---")
        self.aMotionVal.config(text="---")
        self.aReturnVal.config(text="---")
        self.mixRise.config(text="---")

        self.bTankTemp.config(text="---")
        self.bPumpRev.config(text="---")
        self.bPumpPres.config(text="---")
        self.bMotionVal.config(text="---")
        self.bReturnVal.config(text="---")

        self.aTankLiquid.config(text="---")
        self.aTankRoom.config(text="---")
        self.aHoseTemp.config(text="---")
        self.mixingHead.config(text="---")

        self.bTankLiquid.config(text="---")
        self.bTankRoom.config(text="---")
        self.bHoseTemp.config(text="---")



        self.ucl_aTankTemp.config(text="---")
        self.ucl_aPumpRev.config(text="---")
        self.ucl_aPumpPres.config(text="---")
        self.ucl_aMotionVal.config(text="---")
        self.ucl_aReturnVal.config(text="---")

        self.lcl_aTankTemp.config(text="---")
        self.lcl_aPumpRev.config(text="---")
        self.lcl_aPumpPres.config(text="---")
        self.lcl_aMotionVal.config(text="---")
        self.lcl_aReturnVal.config(text="---")

        self.ucl_bTankTemp.config(text="---")
        self.ucl_bPumpRev.config(text="---")
        self.ucl_bPumpPres.config(text="---")
        self.ucl_bMotionVal.config(text="---")
        self.ucl_bReturnVal.config(text="---")

        self.lcl_bTankTemp.config(text="---")
        self.lcl_bPumpRev.config(text="---")
        self.lcl_bPumpPres.config(text="---")
        self.lcl_bMotionVal.config(text="---")
        self.lcl_bReturnVal.config(text="---")

        self.ucl_aTankLiquid.config(text="---")
        self.ucl_aTankRoom.config(text="---")
        self.ucl_aHoseTemp.config(text="---")

        self.lcl_aTankLiquid.config(text="---")
        self.lcl_aTankRoom.config(text="---")
        self.lcl_aHoseTemp.config(text="---")

        self.ucl_bTankLiquid.config(text="---")
        self.ucl_bTankRoom.config(text="---")
        self.ucl_bHoseTemp.config(text="---")

        self.lcl_bTankLiquid.config(text="---")
        self.lcl_bTankRoom.config(text="---")
        self.lcl_bHoseTemp.config(text="---")




def Generate_Unique_ID():
    global clGeneratedControlNo

    dt = datetime.now()
    cl = f"CL-{dt.strftime(f'%y%m%d')}"

    db.Module.query = "SELECT COUNT (fldId) AS mano FROM RPI_ControlLimit WHERE fldUniqueId LIKE ?"
    db.Module.parameter = f'%{cl}%'
    db.Module.openquery()
    db.Module.opencommand()
    readDB = db.Module.exeReader()
    if readDB:
        for rows in readDB:
            clCnt = int(rows.mano) + 1
        clGeneratedControlNo = f"{cl}-{clCnt:04}"
    db.Module.closeqry()
    return clGeneratedControlNo

def is_float(string):
    try:
        float(string)
        return True
    except ValueError:
        return False

def Run_MonitorPage(master, switch_frame, root):
    app = MonitorApp(master, switch_frame, root)
    app.pack()

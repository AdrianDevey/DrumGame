from os import system
from time import sleep
from tkinter import *
from tkinter import messagebox
from tkinter.font import BOLD, ITALIC

import mainPage
from Tools import MachineInfo

#Database
from Database import module_v2 as db
from Database import moduleEMS as dbEMS

class Maintenance(Frame):
    def __init__(self, master, switch_frame, ugat):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame
        self.root = ugat

        Maintenance.Machine_Details(self)

    def Machine_Details(self):
        maintenanceFrame = Frame(self)
        maintenanceFrame.pack(side=LEFT, fill= BOTH, expand=1, padx = 10, pady = 10)
        maintenanceFrame.pack_propagate(False)
        maintenanceFrame.configure(height=600, width=1024)

        machineDetailsFrame = Frame(maintenanceFrame)
        machineDetailsFrame.pack(side = TOP, fill = X, expand= False)

        # Page Title
        lblMaintenance = Label(machineDetailsFrame, text = "Maintenance", font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblMaintenance.pack(side = TOP, fill= BOTH, padx=(15,0), pady=(15, 0))

        line = Canvas(machineDetailsFrame, width = 730, height = 1, bg = "Gray")
        line.pack()

        detailsFrame = Frame(maintenanceFrame)
        detailsFrame.pack(side = TOP, fill = X, expand= False)

        # Machine Details
        lblMachineDetail = Label(detailsFrame, text = "Machine Details", font = ("Bahnschrift", 18, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblMachineDetail.grid(row= 0, column=0, padx=(15,0), pady=(15,0), sticky=NW, columnspan=2)

        lblMachineId = Label(detailsFrame, text = "Machine ID:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblMachineId.grid(row= 1, column=0, padx=(30,0), sticky=NW)

        lblMachineName = Label(detailsFrame, text = "Machine Name:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblMachineName.grid(row= 2, column=0, padx=(30,0), sticky=NW)

        lblStatus = Label(detailsFrame, text = "Status:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblStatus.grid(row= 3, column=0, padx=(30,0), sticky=NW)

        machineId = Label(detailsFrame, text = MachineInfo.machineId, font = ("Bahnschrift", 15, BOLD), justify = LEFT, fg="Black", anchor = "w")
        machineId.grid(row= 1, column=1, padx=(10,0), sticky=NW)

        machineName = Label(detailsFrame, text = MachineInfo.machineName, font = ("Bahnschrift", 15, BOLD), justify = LEFT, fg="Black", anchor = "w")
        machineName.grid(row= 2, column=1, padx=(10,0), sticky=NW)

        machineStatus = Label(detailsFrame, text = MachineInfo.status, font = ("Bahnschrift", 15, BOLD, ITALIC), justify = LEFT, fg="Black", anchor = "w")
        machineStatus.grid(row= 3, column=1, padx=(10,0), sticky=NW)

        if MachineInfo.status == "Operational":
            machineStatus.config(fg = 'Green')
        elif MachineInfo.status == "Down":
            machineStatus.config(fg='Red')
        elif MachineInfo.status == "For Repair":
            machineStatus.config(fg='#F3950D')
        elif MachineInfo.status == "Monitoring":
            machineStatus.config(fg='#0F2C67')
        else:
            machineStatus.config(fg='#000000')

        
        # Change Machine
        line = Canvas(maintenanceFrame, width = 730, height = 1, bg = "Gray")
        line.pack(pady=15)

        # Change Machine Details
        global changeFrame, btnCancel
        changeFrameContainer = Frame(maintenanceFrame)
        changeFrameContainer.pack(side = TOP, fill = X, expand= False)

        btnChange = Button(changeFrameContainer, text = "Use Different Machine", font = ("Bahnschrift", 10, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=2, width = 15, justify=CENTER, wraplength=100, command=Maintenance.Show_Widget)
        btnChange.grid(row=0, column=0, pady = (0, 15), padx=(15,0), sticky=NW)


        changeFrame = Frame(changeFrameContainer)
        changeFrame.grid(row=2, column=0, padx=(15,0), sticky=NW, columnspan= 3)

        line = Canvas(changeFrame, width = 730, height = 1, bg = "Gray")
        line.grid(row=0, column=0, pady = (0, 15), sticky=NW, columnspan= 3)

        changeFrame.grid_forget()

        verifyFrame =  Frame(changeFrame)
        verifyFrame.grid(row = 2, column=0, sticky=NW, columnspan= 3)

        # Change Machine - Registration
        lblMachineId = Label(verifyFrame, text = "Machine ID:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblMachineId.grid(row= 1, column=0, padx=(15,0), sticky=NW)

        global txtVerifyMachineID
        txtVerifyMachineID =  Entry(verifyFrame, width = 20, font = ("Bahnschrift", 15), fg="Black")
        txtVerifyMachineID.grid(row= 1, column=1, sticky=NW)

        btnVerify = Button(verifyFrame, text = "Verify", font = ("Bahnschrift", 12, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 10, justify=CENTER, command=self.Verify_Machine)
        btnVerify.grid(row=1, column=2, pady = (0, 15), padx=(10,0), sticky=NW)

        btnCancel = Button(verifyFrame, text = "X", font = ("Bahnschrift", 12, "bold"), fg="white",  bg = "#D04848",  bd = 0,  height=1, width = 5, justify=CENTER, command=Maintenance.Hide_widget)
        btnCancel.grid(row=1, column=3, pady = (0, 15), padx=(5,220), sticky=NW)


        # Verify Machine Details
        global verifyDetailsFrame
        verifyDetailsFrame = Frame(verifyFrame)
        verifyDetailsFrame.grid(row=2, column=0, padx=(15,0), sticky=NW, columnspan= 4)
        
        # lblMachineName = Label(verifyFrame, text = "Machine Name:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        # lblMachineName.grid(row= 0, column=0, sticky=NW)

    def Show_Widget():
        changeFrame.grid(row=2, column=0, padx=(15,0), sticky=NW, columnspan= 3)

    def Hide_widget():
        changeFrame.grid_forget()
    
    def Verify_Machine(self):
        
        dbEMS.Module.openquery()
        dbEMS.Module.query = "SELECT * FROM EMS_MachineMasterlist WHERE fldMachineID = ?"
        dbEMS.Module.parameter = txtVerifyMachineID.get()
        dbEMS.Module.opencommand()
        findMachine = dbEMS.Module.exeReader()
        if findMachine:
            for row in findMachine:
                lblMachineId = Label(verifyDetailsFrame, text = "Machine ID:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
                lblMachineId.grid(row= 1, column=0, padx=(15,0), sticky=NW)

                lblMachineName = Label(verifyDetailsFrame, text = "Machine Name:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
                lblMachineName.grid(row= 2, column=0, padx=(15,0), sticky=NW)

                lblStatus = Label(verifyDetailsFrame, text = "Status:", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
                lblStatus.grid(row= 3, column=0, padx=(15,0), sticky=NW)

                global verifyMachineId
                verifyMachineId = Label(verifyDetailsFrame, text = row.fldMachineID, font = ("Bahnschrift", 15, BOLD), justify = LEFT, fg="Black", anchor = "w")
                verifyMachineId.grid(row= 1, column=1, padx=(10,0), sticky=NW)

                verifyMachineName = Label(verifyDetailsFrame, text = row.fldMachineName, font = ("Bahnschrift", 15, BOLD), justify = LEFT, fg="Black", anchor = "w")
                verifyMachineName.grid(row= 2, column=1, padx=(10,0), sticky=NW)

                verifyMachineStatus = Label(verifyDetailsFrame, text = row.fldStatus, font = ("Bahnschrift", 15, BOLD, ITALIC), justify = LEFT, fg="Black", anchor = "w")
                verifyMachineStatus.grid(row= 3, column=1, padx=(10,0), sticky=NW)

                if row.fldStatus == "Operational":
                    verifyMachineStatus.config(fg = 'Green')
                elif row.fldStatus == "Down":
                    verifyMachineStatus.config(fg='Red')
                elif row.fldStatus == "For Repair":
                    verifyMachineStatus.config(fg='#F3950D')
                elif row.fldStatus == "Monitoring":
                    verifyMachineStatus.config(fg='#0F2C67')

                btnChange = Button(verifyDetailsFrame, text = "Change Machine", font = ("Bahnschrift", 12, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, justify=CENTER, command=self.Change_Machine)
                btnChange.grid(row=4, column=0, pady = 15, padx=(15,0), sticky=NW)
        else:
            messagebox.showerror("No Machine Found","No Machine Found! Please check carefully if the machine ID entered is correct.")
        
    def Change_Machine(self):
        dbEMS.Module.openquery()
        dbEMS.Module.query = "SELECT * FROM EMS_MachineMasterlist WHERE fldMachineID = ?"
        dbEMS.Module.parameter = verifyMachineId.cget("text")
        dbEMS.Module.opencommand()
        findMachine = dbEMS.Module.exeReader()
        if findMachine:
            for row in findMachine:
                if row.fldStatus == "Operational":
                    msg = messagebox.askyesnocancel("Change Machine Confirmation", "Please confirm before proceed. Do you want to continue?")
                    if msg == 1:
                        db.Module.openquery()
                        db.Module.query = "UPDATE RPI_CurrentMachine SET fldMachineId = ?, fldMachineName = ? WHERE fldIPaddress = ? AND fldCurrentUser = ? AND fldHostname = ?"
                        db.Module.parameter = ()
                        parameter = list(db.Module.parameter)
                        parameter.append(row.fldMachineID)
                        parameter.append(row.fldMachineName)
                        parameter.append(MachineInfo.ipAddress)
                        parameter.append(MachineInfo.pcUser)
                        parameter.append(MachineInfo.hostname)
                        db.Module.parameter = tuple(parameter)
                        db.Module.opencommand()
                        db.Module.conn.commit()
                        db.Module.closeqry()
                        
                        self.root.destroy()
                        system("python mainPage.py")
                        sleep(0.2)
                        

                    elif msg == 0:
                        pass
                    else:
                        Maintenance.Hide_widget()
                
                else:
                    messagebox.showerror(f"Machine is not operational", f"Machine '{row.fldMachineID}( {row.fldMachineName} )' is not operational.")
                    
        dbEMS.Module.closeqry()

    

def Run_MaintenancePage(master, switch_frame, ugat):
    app = Maintenance(master, switch_frame, ugat)
    app.pack()
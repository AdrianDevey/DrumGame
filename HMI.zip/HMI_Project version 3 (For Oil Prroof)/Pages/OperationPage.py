from datetime import datetime
from tkinter import *
from tkinter import messagebox
from datetime import datetime

import Database.module_v2 as db
import mainPage
import Pages.RunPage as RunPage

from Tools import MachineInfo

class OperationApp(Frame):
    def __init__(self, master, switch_frame, runIndicate, hideIndicate):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame
        self.runIndicate = runIndicate
        self.hideIndicate = hideIndicate

        frameOperation = Frame(self)
        
        # Page Title
        lblProductionMode = Label(frameOperation, text = "Production Data ", font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblProductionMode.pack(side = TOP, fill= BOTH)

        ### -- Operation Page Labels -- #########################################################################################################
        lblProgramNo = Label(frameOperation, text = "Program No.: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblModelType = Label(frameOperation, text = "Model Type: ", font = ("Bahnschrift", 15),  justify = LEFT, fg="Black", anchor = "w")
        lblModelNo = Label(frameOperation, text = "Model No.: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblShopOrder = Label(frameOperation, text = "Shop Order: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblProductQty = Label(frameOperation, text = "Product Qty: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        lblCycleTime = Label(frameOperation, text = "Cycle Time: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        # lblTargetlQty= Label(frameOperation, text = "Target Qty: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        # lblActualQty= Label(frameOperation, text = "Actual Qty: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        # lblTotalQty= Label(frameOperation, text = "Total Qty: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")
        # lblStatus = Label(frameOperation, text = "Status: ", font = ("Bahnschrift", 15), justify = LEFT, fg="Black", anchor = "w")

        lblProgramNo.pack()
        lblModelType.pack()
        lblModelNo.pack()
        lblShopOrder.pack()
        lblProductQty.pack()
        lblCycleTime.pack()
        # lblActualQty.pack()
        # lblTargetlQty.pack()
        # lblTotalQty.pack()
        #lblStatus.pack()

        lblProgramNo.place(x = 75, y = 70)
        lblModelNo.place(x = 75, y = 110)
        lblModelType.place(x = 75, y = 150)
        lblShopOrder.place(x = 75, y = 190)
        lblProductQty.place(x = 75, y = 230)
        lblCycleTime.place(x = 75, y = 270)
        # lblTargetlQty.place(x = 75, y = 310)
        # lblActualQty.place(x = 75, y = 350)
        # lblTotalQty.place(x = 75, y = 390)
        # lblStatus.place(x = 75, y = 310)

        ### -- Operation Page Textboxes -- #########################################################################################################
        txtProgramNo =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        txtModelNo =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        txtModelType =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        txtShopOrder =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        txtProductionQty =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        txtCycleTime =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        # txtTargetQty =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        # txtActualQty =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")
        # txtTotalQty =  Entry(frameOperation, width = 40, background="White", font = ("Bahnschrift", 15), fg="Black")

        # ComboBox
        # status = ('Partial', 'Completed')
        # statusString = StringVar(value = status[0])
        # txtStatus =  Combobox(frameOperation, textvariable=statusString, height= 1,  width=20, background="White", font = ("Bahnschrift", 15))
        # txtStatus['values'] = status
        #txtStatus.configure(values= status)

        txtProgramNo.pack()
        txtModelNo.pack()
        txtModelType.pack()
        txtShopOrder.pack()
        txtProductionQty.pack()
        txtCycleTime.pack()
        # txtTargetQty.pack()
        # txtActualQty.pack()
        # txtTotalQty.pack()
        #txtStatus.pack()

        txtProgramNo.place(x = 250, y = 70)
        txtModelNo.place(x = 250, y = 110)
        txtModelType.place(x = 250, y = 150)
        txtShopOrder.place(x = 250, y = 190)
        txtProductionQty.place(x = 250, y = 230)
        txtCycleTime.place(x = 250, y = 270)
        # txtTargetQty.place(x = 250, y = 310)
        # txtActualQty.place(x = 250, y = 350)
        # txtTotalQty.place(x = 250, y = 390)
        #txtStatus.place(x = 250, y = 310)


        ### -- Operation Page Buttons -- #########################################################################################################
        btnFrame = Frame(frameOperation, height=50)

        btnStop = Button(btnFrame, text = "Stop", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER)
        btnStop.pack(padx=10)

        btnReset = Button(btnFrame, text = "Reset", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER)
        btnReset.pack(padx=10)

        btnStart = Button(btnFrame, text = "Start", font = ("Bahnschrift", 18, "bold"), fg="white",  bg = "#1253a3",  bd = 0,  height=1, width = 15, justify=CENTER , command= lambda: Start())
        btnStart.pack(padx=10)

        btnStop.place(x = 0, y = 0)
        btnReset.place(x = 275, y = 0)
        btnStart.place(x = 548, y = 0)

        btnFrame.pack(side = BOTTOM, expand=False, fill = BOTH)

        frameOperation.pack(side = TOP, fill = BOTH, expand=True, padx = 10, pady = 10)
        frameOperation.pack_propagate(False)
        frameOperation.configure(height=600, width=1024)


        def Start():
            import mainPage
            GenerateUniqueID()
            uniqueId = prodGeneratedID
            programNumber = txtProgramNo.get()
            modelNumber = txtModelNo.get()
            modelType = txtModelType.get()
            shopOrder = txtShopOrder.get()
            productQty = txtProductionQty.get()
            cycleTime = txtCycleTime.get()
            actualQty = 0
            targetQty = 0
            totalQty = 0
            #status = txtStatus.get()
            dt = datetime.now()
        
            if programNumber != "" and modelNumber !="" and modelType != "" and shopOrder != "" and productQty != "" and cycleTime != "" and actualQty != "" and totalQty != "" and totalQty != "":
                              
                db.Module.query = "INSERT INTO RPI_Operation (fldUniqueId, fldMachineId, fldProgramNo, fldModelNo, fldModelType, fldShopOrder, fldProductQty, fldCycleTime, fldActualQty, fldTarget, fldTotalQty, fldStartTime, fldDateRegistered) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
                db.Module.parameter = ()
                parameter = list(db.Module.parameter)
                parameter.append(uniqueId)
                parameter.append(MachineInfo.machineId)
                parameter.append(programNumber)
                parameter.append(modelNumber)
                parameter.append(modelType)
                parameter.append(shopOrder)
                parameter.append(productQty)
                parameter.append(cycleTime)
                parameter.append(actualQty)
                parameter.append(targetQty)
                parameter.append(totalQty)
                parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
                parameter.append(dt.strftime(f'%m/%d/%Y %H:%M:%S'))
                db.Module.parameter = tuple(parameter)
                db.Module.openquery()
                db.Module.opencommand()
                db.Module.conn.commit()
                db.Module.closeqry()

                for txt in frameOperation.winfo_children():
                    if isinstance(txt, Entry):
                        txt.delete(0, END)

                #Transfer Data to Run Page
                self.Trigger_Run_Page(runIndicate, hideIndicate)
                Start_Function()

            else:
                messagebox.showerror("Missing Information","Please fill all required information")
                #self.Trigger_Run_Page(runIndicate, hideIndicate)
                #Start_Function()
            
        def Stop():
            return

        def Reset():
            return

    def Trigger_Run_Page(self, runIndicate, hideIndicate):
        mainPage.MainApp.DeleteFrame(self.master)
        mainPage.RunPage.Run_RunPage(self.master, self.switch_frame)
        hideIndicate()
        runIndicate.config(bg="White")
        
        
        
        
    def change_indicator(self):
        # Call the callback to change the runIndicate color
        self.run_indicator_callback()
            

def GenerateUniqueID():
    global prod ,prodCnt, prodGeneratedID 

    dt = datetime.now()
    prod = f"PROD-{dt.strftime(f'%y%m%d')}"

    db.Module.query = "SELECT COUNT (fldId) AS mano FROM RPI_Operation WHERE fldUniqueId LIKE ?"
    db.Module.parameter = f'%{prod}%'
    db.Module.openquery()
    db.Module.opencommand()
    readDB = db.Module.exeReader()
    if readDB:
        for rows in readDB:
            prodCnt = int(rows.mano) + 1
        prodGeneratedID = f"{prod}-{prodCnt:04}"
    db.Module.closeqry()
    return prodGeneratedID
    


def Run_OperationPage(master, switch_frame, runIndicate, hideIndicate):
    app = OperationApp(master, switch_frame, runIndicate, hideIndicate)
    app.pack()


def Start_Function():
    db.Module.openquery()
    db.Module.query  = "SELECT TOP 1 * FROM RPI_Operation ORDER BY fldId DESC"
    db.Module.parameter = None
    db.Module.opencommand()
    read = db.Module.exeReader()
    if read:
        for row in read:    
            RunPage.uniqueId = row.fldUniqueId
            RunPage.programNumber.config(text=row.fldProgramNo)
            RunPage.modelNumber.config(text=row.fldModelNo)
            RunPage.modelType.config(text=row.fldModelType)
            RunPage.shopOrder.config(text=row.fldShopOrder)
            RunPage.productQty.config(text= row.fldProductQty)
            RunPage.cycleTime.config(text=row.fldCycleTime)
            #RunPage.status.config(text=row.fldStatus)

            timestamp = row.fldStartTime
            dt = timestamp.strftime("%I:%M:%S %p\n%m/%d/%Y")
            RunPage.startTime.config(text=dt)

            RunPage.actualQty.config(text=row.fldActualQty)
            RunPage.targetQty.config(text=row.fldTarget)
    db.Module.closeqry()
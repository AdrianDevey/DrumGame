from tkinter import *
from tkinter.ttk import Treeview

from Database import module_v2 as db
from Tools import MachineInfo


class HistoryApp(Frame):
    def __init__(self, master, switch_frame):
        super().__init__(master)
        self.master = master
        self.switch_frame = switch_frame

        self.HistoryPage()

    def HistoryPage(self):
        frameHistory = Frame(self)

        # Page Title
        lblRun = Label(frameHistory, text = "History Log ", font = ("Bahnschrift", 20, "bold"), justify = LEFT, fg="Black", anchor = "w")
        lblRun.pack(side = TOP, fill= BOTH)

        # Tree View
        frameLog = Frame(frameHistory)

        treeviewItem = []
        db.Module.openquery()
        db.Module.query = "SELECT * FROM RPI_Operation WHERE fldMachineId = ? ORDER BY fldId DESC"
        db.Module.parameter = MachineInfo.machineId
        db.Module.opencommand()
        rows = db.Module.exeReader()

        if rows:
            for row in rows:
                item = [
                    row.fldProgramNo,
                    row.fldModelNo,
                    row.fldModelType,
                    row.fldShopOrder,
                    row.fldProductQty,
                    row.fldCycleTime,
                    row.fldActualQty,
                    row.fldTarget,
                    row.fldStatus,
                    row.fldStartTime,
                    row.fldStopTime
                ]
                treeviewItem.append(item)
        db.Module.closeqry()
        
        cols = ('progNo', 'modelNo', 'modelType', 'shopOrder', 'productQty', 'cycleTime', 'actualQty', 'target', 'status', 'startTime', 'stopTime')


        

        tv_log = Treeview(frameLog, columns=cols, show='headings')


        tv_log.column('progNo', width= 125, anchor=CENTER)  
        tv_log.column('modelNo', width= 125, anchor=CENTER)  
        tv_log.column('modelType', width= 125, anchor=CENTER)  
        tv_log.column('shopOrder', width= 125, anchor=CENTER)  
        tv_log.column('productQty', width= 125, anchor=CENTER)  
        tv_log.column('cycleTime', width= 125, anchor=CENTER)  
        tv_log.column('actualQty', width= 125, anchor=CENTER)  
        tv_log.column('target', width= 125, anchor=CENTER)  
        tv_log.column('status', width= 125, anchor=CENTER)  
        tv_log.column('startTime', width= 125, anchor=CENTER)  
        tv_log.column('stopTime', width= 125, anchor=CENTER)  

        # Headings
        tv_log.heading('progNo', text= "Program No.")  
        tv_log.heading('modelNo', text= "Model No.")  
        tv_log.heading('modelType', text= "Model Type")  
        tv_log.heading('shopOrder', text= "Shop Order")  
        tv_log.heading('productQty', text= "Product Qty")  
        tv_log.heading('cycleTime', text= "Cycle Time")  
        tv_log.heading('actualQty', text= "Actual Qty")  
        tv_log.heading('target', text= "Target Qty")  
        tv_log.heading('status', text= "Status")  
        tv_log.heading('startTime', text= "Start Time")  
        tv_log.heading('stopTime', text= "Stop Time")  

        for logItem in treeviewItem:
            tv_log.insert('', END, values=logItem)


            
        def item_selected(event):
            for selected_item in tv_log.selection():
                item = tv_log.item(selected_item)
                record = item['values']

                #showinfo(title= "Information", message = ','.join(record))

        tv_log.bind('<<TreeviewSelect>>', item_selected)
        tv_log.pack(side=TOP, fill= BOTH, expand=True)

        xScroll = Scrollbar(frameLog, orient=HORIZONTAL, command=tv_log.xview)
        tv_log.configure(xscrollcommand=xScroll.set)
        xScroll.pack(side=BOTTOM, fill = X)

        

        frameLog.pack(side=TOP, fill= BOTH, expand = True)

        frameHistory.pack(side=LEFT, fill= BOTH, expand=1, padx = 10, pady = 10)
        frameHistory.pack_propagate(False)
        frameHistory.configure(height=600, width=1024)




    def close_history_app(self):
        self.pack_forget()
        self.switch_frame()




def Run_HistoryPage(master, switch_frame):
    app = HistoryApp(master, switch_frame)
    app.pack(side= LEFT, fill = BOTH, expand=True)